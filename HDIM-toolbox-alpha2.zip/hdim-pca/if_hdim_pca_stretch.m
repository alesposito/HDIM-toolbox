function O = if_hdim_pca_stretch(I,M,stretch_method)
I(isnan(I)) = 0;
switch lower(stretch_method)
    case {'std'}
        mm = mean(I(M))-1*std(I(M));
        MM = mean(I(M))+3.5*std(I(M));
        O = M.*(I - mm)/(MM-mm);
        O(O<0)=0;
        O(O>1)=1;
    case {'min-max'}
        mm = min(I(M));
        MM = max(I(M));
        O = M.*(I - mm)/(MM-mm);
        O(O<0)=0;
        O(O>1)=1;
    case {'min-3s'}
        mm = min(I(M));
        MM = mean(I(M))+3*std(I(M));
        O = M.*(I - mm)/(MM-mm);
        O(O<0)=0;
        O(O>1)=1;
end

