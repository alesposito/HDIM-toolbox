% VERSION 4.1
% 4.1 uniqueness of pixels guaranteed

if bExcludeBackground
    %thr = 10;mean(dc)-0*std(dc);
    mk = HDIM_VIS.msk_2d;
else
    mk = dc>1;
end
    

%% randomize pixels - guarantee uniqueness
idx = find(mk);
if n>=size(idx,1)
    n = size(idx,1);
    ord = (1:n);
else
    ord = unique(nonzeros(ceil(rand([1 2*n])*size(idx,1))));
    ord = ord(1:n);    
end
idx = idx(ord); 
%clear dc

%%
if bIOprojections==1
   eval(['load ''' load_path_pca  load_name_pca ''';']); 
    HDIM_CAL.pca.coeff        = v1; 
    HDIM_CAL.pca.limits       = v2;
    HDIM_CAL.kmeans.coeff_pca = v3;
    HDIM_CAL.kmeans.coeff_phy = v4;
else
    switch ExtractionType
        case 1           
           [COEFF,SCORE] = pca2(img(idx,:)');            
        case 2
            [latent,COEFF,SCORE]=robpca(img(idx,:),HDIM_PAR.t_dim*HDIM_PAR.s_dim,@mad);
        case 3
            COEFF = ThinICAnew(img(idx,:)',n_comp)';
    end
    

HDIM_CAL.pca.coeff = COEFF;
end


%%
clear mk COEFF tmp criterion