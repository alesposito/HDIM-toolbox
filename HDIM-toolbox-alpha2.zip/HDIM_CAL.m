% VERSION 5
% Improved GUI and added dark counts

close all
clear all

% Create HDIM structures
[HDIM_CAL, HDIM_PAR, HDIM_VIS, HDIM_CST] = if_hdim_init;
    
%% Define file names and paths
HDIM_CAL.files = if_hdim_cal_files;

%% Input Laser Comb - Edit HDIM_CAL.Info.r_target and HDIM_CAL.Comb by GUI 
if_hdim_calibration_gui;

%% Spectral calibration
[HDIM_PAR HDIM_CAL img] = if_hdim_cal_spectral(HDIM_PAR, HDIM_CAL);

%% Set default dimensions
HDIM_PAR.x_dim = size(img,1);
HDIM_PAR.y_dim = size(img,2);
HDIM_PAR.t_dim = size(img,4);
clear img

%% Calibrate anisotropy
[HDIM_PAR HDIM_CAL] = if_hdim_cal_anisotropy(HDIM_PAR, HDIM_CAL);

    
%% Temporal calibration - reinstated i V4

[HDIM_PAR HDIM_CAL] = if_hdim_cal_time_tempversion(HDIM_PAR, HDIM_CAL);


%% Save result
eval(['save ''' HDIM_CAL.files.save_path HDIM_CAL.files.calibration ''' HDIM_CAL HDIM_PAR HDIM_VIS HDIM_CST'])

beep 
beep


