% version 2
function [img HDIM_CAL HDIM_PAR HDIM_VIS, HDIM_CST] = if_hdim_load(varargin)    

bBatch = 0;



ticId = tic;

    if nargin==0
        bQuery = 1;        
    elseif nargin==1
        if ~isempty(varargin{1})
            HDIM_PAR = varargin{1};
            if isfield(HDIM_PAR,'batch')
                bBatch = HDIM_PAR.batch;
            end
            
            if ~bBatch
                beep
                ANS = questdlg('Should I load new files (click NO to reload previous selection)?','HDIM','Yes','No','Yes');                
            
                switch lower(ANS)
                    case 'yes' 
                        bQuery = 1;
                    case 'no'
                        bQuery = 0;
                end
            else
                bQuery = 0;
            end

        else
            bQuery = 1;
        end
    else
        if_voice('Error!',[],1)
        error([mfilename '> too many input parameters'])
    end
        
    if bQuery
        [HDIM_CAL, HDIM_PAR, HDIM_VIS, HDIM_CST] = if_hdim_init;
    
        % suppoerted file names
        file_types = '*hdim*.mat;*.sdt;*.mat';

        % query for file locations
        [file_name1 file_path1] = uigetfile(file_types,'Select HDIM file...');
        cd(file_path1);
        [file_name2 file_path2] = uigetfile('*cal*.mat','Select calibration file)...');
    else
        file_name1 = HDIM_PAR.file_name;  
        file_path1 = [HDIM_PAR.file_path '/'];  
        file_name2 = HDIM_PAR.cal_name;   
        file_path2 = [HDIM_PAR.cal_path '/'];   
    end
    
    % load
    
    eval(['load '''   file_path2  file_name2 ''';']);
    
    switch lower(file_name1(end-2:end))
        case 'mat'
            eval(['load ''' file_path1 file_name1 ''';']);
        case 'sdt'
            [img, hdr, asc, TCSPC, msd] = if_bh_loadsdt([file_path1 file_name1 ]);
            
            HDIM_PAR.TCSPC.hdr   = hdr;
            HDIM_PAR.TCSPC.asc   = asc;
            HDIM_PAR.TCSPC.TCSPC = TCSPC;
            HDIM_PAR.TCSPC.msd   = msd;
            HDIM_PAR.TCSPC.hdr   = hdr;
        otherwise
            display([mfilename '> FILE FORMAT NOT SUPPORTED'])
    end      
        
    % Update HDIM_PAR
    HDIM_PAR.file_name = file_name1;
    HDIM_PAR.file_path = file_path1;
    HDIM_PAR.cal_name  = file_name2;
    HDIM_PAR.cal_path  = file_path2; 
    HDIM_PAR.h.ticVb = if_voice('Dataset loaded',ticId,2);    