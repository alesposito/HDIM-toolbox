% VERSION 5.1

function [HDIM_CAL HDIM_PAR] = if_hdim_getdimensions(img, HDIM_CAL, HDIM_PAR)

    %%  --- Solve Back Compatibility Issues (from v4) ---
    % Check if HDIM_PAR exists, if not initialize it @@@ create a function for this, linked to init
    if ~exist('HDIM_PAR'); HDIM_PAR = struct([]); end
    % Now we are sure that HDIM_PAR exists, create - if missing - fields
    if ~isfield(HDIM_PAR,'T_Res'); HDIM_PAR.T_Res = []; end
    if ~isfield(HDIM_PAR,'T_Per'); HDIM_PAR.T_Per = []; end
    if ~isfield(HDIM_PAR,'T_Ome'); HDIM_PAR.T_Ome = []; end
    if ~isfield(HDIM_PAR,'t');     HDIM_PAR.t = [];     end
    % Now er are sure fields exist, populate with values        
    if isempty(HDIM_PAR.T_Per) & exist('TCSPC')
        HDIM_PAR.T_Per = 1E10*if_lifetime_bhpar(TCSPC,'SP_TAC_TD');
    elseif isempty(HDIM_PAR.T_Per) & ~exist('TCSPC')
        HDIM_PAR.T_Per = 12.5;
    end
    if isempty(HDIM_PAR.T_Res) & exist('TCSPC')
       HDIM_PAR.T_Res = 1E10*if_lifetime_bhpar(TCSPC,'SP_TAC_TD')/if_lifetime_bhpar(TCSPC,'SP_ADC_RE');
    elseif isempty(HDIM_PAR.T_Res) & ~exist('TCSPC')
       HDIM_PAR.T_Res = HDIM_PAR.T_Per/(size(img,4)-1);
    end
    if isempty(HDIM_PAR.T_Ome) 
       HDIM_PAR.T_Ome = 2*3.14/HDIM_PAR.T_Per;
    end
    if isempty(HDIM_PAR.t) 
       HDIM_PAR.t = (0:HDIM_PAR.T_Res:HDIM_PAR.T_Per);
    end    

    % Check if HDIM_CAL exists, if not creates it
    if ~exist('HDIM_CAL'); HDIM_CAL = struct([]); end
    % Now we are sure that HDIM_CAL exists, create - if missing - fields
    if ~isfield(HDIM_CAL,'Sp1'); HDIM_CAL.Sp1 = []; end
    if ~isfield(HDIM_CAL,'Sp2'); HDIM_CAL.Sp2 = []; end
    % Now we are sure fields exist, populate with values      
    if isempty(HDIM_CAL.Sp1); HDIM_CAL.Sp1 = [15 450]; end  
    if isempty(HDIM_CAL.Sp2); HDIM_CAL.Sp2 = [15 450]; end  

    % v5.1 addition
    if ~isfield(HDIM_PAR,'Verbose'); HDIM_PAR.Verbose = [];        end  % verbose feedback, 2: speach enabled
    if ~isfield(HDIM_PAR,'PC');      HDIM_PAR.PC      = [];        end  % parallel computing
    if ~isfield(HDIM_PAR,'h');       HDIM_PAR.h       = struct();  end  % handles
    
    if isempty(HDIM_PAR.Verbose); HDIM_PAR.Verbose = 2;        end  % verbose feedback, 2: speach enabled
    if isempty(HDIM_PAR.PC);      HDIM_PAR.PC      = 0;        end  % parallel computing
    %if isempty(HDIM_PAR.h);       HDIM_PAR.h       = struct(); end  % handles    
    % Now all important fields in HDIM_CAL and HDIM_PAR have been created
    

    %% --- BACK COMPATIBILITY BLOCK END HERE

    %%

    % Get matrix dimensions
    HDIM_PAR.x_dim = size(img,1);
    HDIM_PAR.y_dim = size(img,2);
    HDIM_PAR.s_dim = size(img,3);
    HDIM_PAR.t_dim = size(img,4);
    
    % Elements to be included in the analysis
    HDIM_PAR.s_ele = HDIM_PAR.SpElements;
    %HDIM_PAR.s_ele = [3 4 5 6 7 8 9];       % Use this line to limit the spectral chennels to be used

    % Automatically detect the time bins that should be included in the analysis
    [tmp1 tmp2]    = if_lifetime_decaygates((sumch(img,[1 2 3])));
    HDIM_PAR.t_ele = (tmp1:1:tmp2);
    clear tmp1 tmp2
    %HDIM_PAR.t_ele = (1:1:64); % Use this line to limit the time bins to be used

    % Redefine the total number of channels
    HDIM_PAR.s_dim = size(HDIM_PAR.s_ele,2); % total spectral channels
    HDIM_PAR.t_dim = size(HDIM_PAR.t_ele,2); % total time channels

    % Define the indexing for the parallel and orthogonal spectral channels
    HDIM_PAR.idx_par = HDIM_PAR.s_ele+HDIM_PAR.s_dim*(HDIM_PAR.ChPar-1);
    HDIM_PAR.idx_per = HDIM_PAR.s_ele+HDIM_PAR.s_dim*(HDIM_PAR.ChPer-1);

    % Define axis (r-axis does not need defnition as it is inherently defined by physics and not by the setup)
    HDIM_CAL.a_wav1 = if_hdim_spe2wav(HDIM_CAL, HDIM_PAR.s_ele, 1);
    HDIM_CAL.a_wav2 = if_hdim_spe2wav(HDIM_CAL, HDIM_PAR.s_ele, 2);
    HDIM_CAL.a_time = HDIM_PAR.t(HDIM_PAR.t_ele);


