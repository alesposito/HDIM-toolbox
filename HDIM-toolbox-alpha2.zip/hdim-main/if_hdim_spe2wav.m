% ch = 0, min-max, for interpolation
% ch = 1, first channel
% ch = 2, second channel
% ch = 3, both

% spe = array of spectral elements (e.g. (1:16))

function wav = if_hdim_spe2wav(HDIM_CAL, spe, ch)
    wav1 = polyval(HDIM_CAL.Sp1,spe);
    wav2 = polyval(HDIM_CAL.Sp2,spe);
    
    switch ch
        case 0 % this was changed for compatibility with if_hdim_cal_anisotropy from v4.1
            w_min = max([min(wav1) min(wav2)]);
            w_max = min([max(wav1) max(wav2)]);
            w_res = size(wav1,2);
            wav   = w_min:(w_max-w_min)/(w_res-1):w_max;            
        case 1
            wav = wav1;
        case 2
            wav = wav2;
        case 3
            wav = [wav1; wav2];
    end