% version 2

function HDIM_PAR = if_hdim_plot3d(img, HDIM_PAR, HDIM_CAL)
    transparency = 1;
    
    if ~isfield(HDIM_PAR,'file_name')
        HDIM_PAR.file_name = [];
    end
    
    
    HDIM_PAR.h.figs.hdimplot = figure('name',['HDIM PLOT (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');

    iX = size(HDIM_PAR.t,2);
    iY  = size(HDIM_CAL.a_wav0,2);
    
    yvs = mean(diff(HDIM_CAL.a_wav0)); % spectral spacing
    yva = .005; % fractional spacing
    
    values = sumch(img,[1 2]);
    sp1 = sumch(img(:,:,HDIM_PAR.idx_par,:),[1 2 4]);
    sp2 = sumch(img(:,:,HDIM_PAR.idx_per,:),[1 2 4]);
    r = (sp1-sp2)./(sp1+2*sp2);

    mm = max(values(:));

    % time decays
    for i=HDIM_PAR.s_ele(1):HDIM_PAR.s_ele(end)
        patch( HDIM_PAR.t, HDIM_CAL.a_wav0(i)*ones([1 iX]),         squeeze(values(i,:)),    'b','facealpha',transparency)
        patch( HDIM_PAR.t, HDIM_CAL.a_wav0(i)*ones([1 iX])-yva*yvs, squeeze(values(i+16,:)), 'r','facealpha',transparency)
    end

    % spectral projections
    patch(-1*ones([1 iY+2]),   [HDIM_CAL.a_wav0(1) HDIM_CAL.a_wav0 HDIM_CAL.a_wav0(end)],  [0 mm*sp1'/max(sp1(:)) 0],'b','facealpha',transparency)
    patch(-0.9*ones([1 iY+2]), [HDIM_CAL.a_wav0(1) HDIM_CAL.a_wav0 HDIM_CAL.a_wav0(end)],  [0 mm*sp2'/max(sp1(:)) 0],'r','facealpha',transparency)

    % anisotropy decay projecions
    r_max = .52;
    hold on
    plot3(0*ones([1 16]),HDIM_CAL.a_wav0,r*mm/r_max,'k','linewidth',5)
    plot3(0*ones([1 16]),HDIM_CAL.a_wav0,r*mm/r_max,'y','linewidth',3)
    plot3(0*ones([1 16]),HDIM_CAL.a_wav0,mm*ones([1 16]),':y','linewidth',2)

    % set viewing and labels
    view(36,69)
    axis tight
    camproj('perspective')

    set(gca,'xgrid','on','ygrid','on','zgrid','on')
    xlim([ HDIM_PAR.t(1)-1  HDIM_PAR.t(end)+1])
    ylim([HDIM_CAL.a_wav0(1)-1*yvs,HDIM_CAL.a_wav0(end)+1*yvs])

    xlabel('time (ns)')
    ylabel('wavelength (nm)')
    zlabel('photon count (ns)')



