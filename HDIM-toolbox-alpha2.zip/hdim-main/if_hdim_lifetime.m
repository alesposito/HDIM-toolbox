% VERSION 1

% AN      Spectrally resolved anisotropy
% AN_A    (Intensity weigthed) spectrally averaged anisotropy
% r_plot  Anisotropy plot
% f4      handler to figure - 
% f5      handler to figure - 

function LT = if_hdim_lifetime(img, HDIM_CAL, HDIM_PAR, HDIM_VIS, bDisplay, method)
    
    switch lower(method)
        case {'rld','rld-med'}
            %%
            % discard last third the data
            t_dt = floor(HDIM_PAR.t_dim/3);
            t_tv = HDIM_PAR.T_Res*t_dt;
            
            tmp = sumch(img(:,:,HDIM_PAR.idx_par,:)+2*img(:,:,HDIM_PAR.idx_per,:),3);

            RLD1 = sumch(tmp(:,:,HDIM_PAR.t_ele(1)+(0    :   t_dt-1)),3);
            RLD2 = sumch(tmp(:,:,HDIM_PAR.t_ele(1)+(t_dt : 2*t_dt-1)),3);
            
            if strcmp(lower(method),'rld-med')
               RLD1 = medfilt2(RLD1,[3 3],'symmetric') ;
               RLD2 = medfilt2(RLD2,[3 3],'symmetric') ;
            end
            
            
            LT   = -t_tv./log(RLD2./(RLD1+eps));
            %LT   = medfilt2(-t_tv./log(RLD2./RLD1),[3 3]);
            %%
            
            LT(LT<0) = 0;
            LT(isnan(LT)) = 0;
            LT(isinf(LT)) = 0;
        otherwise
            error([mfilename '> no other method defined yet'])
    end
    
    if bDisplay
        figure
        imagesc(HDIM_VIS.msk_2d .* if_hdim_filterdisplay(LT,HDIM_PAR))
        set(gca,'clim',[0 1*max(LT(:))])
        colorbar
        title('lifetime')
        axis image
        axis off
    end