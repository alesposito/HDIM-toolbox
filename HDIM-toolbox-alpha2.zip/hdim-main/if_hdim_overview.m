%V2 
%% Analysis of steady-state anisotropy
[AN AN_A r_plot HDIM_PAR] = if_hdim_anisotropy(img, HDIM_CAL, HDIM_PAR, HDIM_VIS, 1);
%% Analysis of fluorescence lifetime decay
RLDT = if_hdim_lifetime(img, HDIM_CAL, HDIM_PAR, HDIM_VIS, 0, 'RLD');
%%
HDIM_PAR.h.figs.overview1d = figure('name',['Overview 1D (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');

subplot(2,3,1)
decay = sumch(img.*repmat(HDIM_VIS.msk_2d,[1 1 32 64]),[1 2 3]);
decay = decay/max(decay(:))
plot(HDIM_PAR.t,decay,'k')    
set(gca,'ylim',[0 1],'xlim',[min(HDIM_PAR.t) max(HDIM_PAR.t)])
%hold on
title('time decay')

subplot(2,3,2)
spectra = reshape(sumch(img.*repmat(HDIM_VIS.msk_2d,[1 1 32 64]),[1 2 4]),[16 2]);
plot(HDIM_CAL.a_wav0,spectra(:,HDIM_PAR.ChPar),'r')    
hold on
plot(HDIM_CAL.a_wav0,spectra(:,HDIM_PAR.ChPer),'k')  
plot(HDIM_CAL.a_wav0,spectra(:,HDIM_PAR.ChPar)+2*spectra(:,HDIM_PAR.ChPer),'c')  
set(gca,'ylim',[0 max(spectra(:,HDIM_PAR.ChPar)+2*spectra(:,HDIM_PAR.ChPer))],'xlim',[min(HDIM_CAL.a_wav0) max(HDIM_CAL.a_wav0)])
title('spectra')
legend('par','per','tot','location','best')


subplot(2,3,3)    
plot(HDIM_CAL.a_wav0, r_plot,'k')
axis square
set(gca,'ylim',[0 1],'xlim',[min(HDIM_CAL.a_wav0) max(HDIM_CAL.a_wav0)])
xlabel('wavelength (nm)')
ylabel('spatially averaged anisotropy')
title('anisotropy')

drawnow

%% colour
HDIM_PAR.h.figs.rgb = figure('name',['RGB (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
RGB = if_hdim_spec2rgb(sumch(img(:,:,HDIM_PAR.idx_par,:)+2*img(:,:,HDIM_PAR.idx_per,:),4),'type','perception','wavelength',HDIM_CAL.a_wav1,'imoptions',[0 1 2]);
rgbnorm = shiftdim(repmat(squeeze(mean(RGB(:))+3*std(RGB(:))),[3 size(img,1) size(img,2)]),1);
rgbnorm(rgbnorm==0)=1;
imshow(RGB./rgbnorm)
title('color image')

%% lifetime
HDIM_PAR.h.figs.rld = figure('name',['RLD (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
imagesc(HDIM_VIS.msk_2d.*if_hdim_filterdisplay(RLDT,HDIM_PAR))
set(gca,'clim',[0 min([max(RLDT(:)) 12])])
colorbar
title('lifetime')
axis image
axis off

colormap(HDIM_VIS.T_LUT)

%%

R = squeeze(RGB(:,:,1));
G = squeeze(RGB(:,:,2));
B = squeeze(RGB(:,:,3));
A = ((R-G)./(R+G+eps)).^2+((R-B)./(R+B+eps)).^2+((B-G)./(B+G+eps)).^2;
I = (R.*G.*B./(max(R(:)).*max(G(:)).*max(B(:)))).^(1/3);
C = I.*sqrt(A)/3;


idx = find(HDIM_VIS.msk_2d >0); 
msk2 = (HDIM_VIS.msk_2d .*RLDT.*R.*G.*B.*AN_A)>0;
%%

if 1  
    HDIM_PAR.h.figs.plot2d = figure('name',['2D plots (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
    
    toplot=[];

       toplot(1,:) = double(R(idx));
       toplot(2,:) = double(G(idx));
       toplot(3,:) = double(B(idx));
       toplot(4,:) = AN_A(idx);
       toplot(5,:) = RLDT(idx);
       what={'red','green','blue','r','RLD'};
       lowl=[0 0 0 0 0];
       highl=max(toplot');
       highl(3:5) = [highl(3)/2 .7 5];



    for i=1:5
        for j=1:5
           if j<i
            subplot(4,4,(i-1)+(j-1)*4)
            box on
            %xlabel(names{i})
            %ylabel(names{j})        
            if i>3
                b1=512;
            else
                b1=round(highl(i)/4);   
                if b1<10
                    b1=10
                end
            end

            if j>3
                b2=512;
            else
                b2=round(highl(j)/4);
                if b2<10
                    b2=10
                end
            end

            %b1=512
            %b2=512

            if b1>512
                b1=512;
            end
            if b2>512
                b2=512;
            end
            
            s12 = min([b1 b2]);

            dscatter(squeeze(toplot(i,:))',squeeze(toplot(j,:))','smoothing',s12,'bins',[b1 b2],'plottype','image')

            set(gca,'xlim',[lowl(i) highl(i)],'ylim',[lowl(j) highl(j)],'ydir','normal');
            axis square
            ylabel(what{j})
            xlabel(what{i})
            drawnow
           end
        end
    end

    LUT = jet(64);
    LUT(1,:) = [1 1 1];
    colormap(LUT)
end


%%
figure(HDIM_PAR.h.figs.overview1d)

xlt=(0:.05:2);
subplot(2,3,4)  
yyy=histc(nonzeros(RLDT),xlt);
plot(xlt,yyy)
axis square
xlabel('lifetime (ns)')
ylabel('frequency')
title('lifetime')
%%
xrr=(0:.025:1);
subplot(2,3,6)  
yyy=histc(nonzeros(AN_A),xrr);
plot(xrr,yyy)
axis square
xlabel('anisotropy')
ylabel('frequency')
title('r')
%%
xbr=(0:max(nonzeros(cat(3,R,G,B)))/64:max(nonzeros(cat(3,R,G,B))));
subplot(2,3,5)  
yyR=histc(nonzeros(R),xbr);
yyG=histc(nonzeros(G),xbr);
yyB=histc(nonzeros(B),xbr);
plot(xbr,yyR,'r')
hold on
plot(xbr,yyR,'r')
plot(xbr,yyG,'g')
plot(xbr,yyB,'b')
axis square
xlabel('intensity')
ylabel('frequency')
title('br')
set(gca,'yscale','log')


