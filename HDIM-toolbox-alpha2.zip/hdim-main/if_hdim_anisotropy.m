% VERSION 4.1

% AN      Spectrally resolved anisotropy
% AN_A    (Intensity weigthed) spectrally averaged anisotropy
% r_plot  Anisotropy plot
% f4      handler to figure - 
% f5      handler to figure - 

function [AN AN_A r_plot HDIM_PAR] = if_hdim_anisotropy(img, HDIM_CAL, HDIM_PAR, HDIM_VIS, bDisplay)
%%
    AN = zeros([sizech(img,[1 2]) HDIM_PAR.s_dim 2]);    
    AN(:,:,:,1) = sumch(img(:,:,HDIM_PAR.idx_par,:),4);
    AN(:,:,:,2) = sumch(img(:,:,HDIM_PAR.idx_per,:),4);

    AN_DC =  sumch(img(:,:,HDIM_PAR.idx_par,:),4) +2*sumch(img(:,:,HDIM_PAR.idx_per,:),4);
    AN    = (sumch(img(:,:,HDIM_PAR.idx_par,:),4) -  sumch(img(:,:,HDIM_PAR.idx_per,:),4))./AN_DC;

    AN(isnan(AN))=0;
    AN(AN<0)=0;
    AN(AN>1)=1;
    AN    = HDIM_VIS.msk_hd .* AN;
    
    % intensity weighted
    AN_A = sum((AN .* AN_DC),3)./sum(AN_DC,3);
    AN_A(AN_A<0)=0;
        
    AN_A(AN_A>1)=1;
    AN_A(isnan(AN_A))=0;
    AN_A  = HDIM_VIS.msk_2d .* AN_A;
           
    
    % r profile
    r_plot = squeeze(sum(sum(  AN.*HDIM_VIS.msk_hd  ,1),2)./sum(sum(AN_DC>10,1),2));
    r_plot(isnan(r_plot)) = 0;

    
    %% DISPLAY
    if bDisplay
        HDIM_PAR.h.figs.spectral_r = figure('name',['Spectral anisotropy (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
        for i=1:16
           subplot(4,4,i)
           imagesc(if_hdim_filterdisplay((AN_DC(:,:,i)>5).*AN(:,:,i),HDIM_PAR));
           axis off;
           axis image       
           set(gca,'clim',[0 1])       
        end
        colormap(HDIM_VIS.R_LUT)    

        HDIM_PAR.h.figs.anisotropy = figure('name',['Average anisotropy (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
        subplot(1,2,1)
        imagesc(HDIM_VIS.msk_2d .*if_hdim_filterdisplay(AN_A,HDIM_PAR))
        set(gca,'clim',[0 1])
        colormap(HDIM_VIS.R_LUT)
        colorbar
        title('Anisotropy')
        axis image
        axis off

        subplot(1,2,2)
        plot(HDIM_CAL.a_wav0, r_plot)
        set(gca,'ylim',[0 1],'xlim',[min(HDIM_CAL.a_wav0) max(HDIM_CAL.a_wav0)])
        axis square
        xlabel('wavelength (nm)')
        ylabel('spatially averaged anisotropy')

    end