% VERSION 1.1

function HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR)

    % V1.1b
    HDIM_VIS.msk_hd = (sumch(img(:,:,HDIM_PAR.idx_par,:),[4]) + sumch(img(:,:,HDIM_PAR.idx_per,:),[4])) > thr;

    % V1.1
    %HDIM_VIS.msk_hd = (sumch(img(:,:,HDIM_PAR.idx_par,:),[4])>thr & sumch(img(:,:,HDIM_PAR.idx_per,:),[4])>thr);

    % V1.0
    %HDIM_VIS.msk_hd = sumch(reshape(img,[size(img,1) size(img,2) size(img,3)/2 2 size(img,4)]),[4 5]);
    %HDIM_VIS.msk_hd = (HDIM_VIS.msk_hd > thr) ;
    
    
    HDIM_VIS.msk_2d = (sumch(HDIM_VIS.msk_hd,3)>0);

    %@@ may be adding here morphological operations to mask
