function data = if_hdim_filterdisplay(data, HDIM_PAR)
    if HDIM_PAR.filter_display.status
        data = medfilt2(data,HDIM_PAR.filter_display.kernel,'symmetric');
    end
        