function [peak stop] = if_lifetime_decaygates(decay)
%%
    d = size(decay,1);
    x  = (1:.1:d);
    y  = interp1((1:d),decay,x,'pchip');

    peak = round(x(round(mean(find(y==max(y(1:round(size(y,2)/2))))))));
    %peak = round(x(round(mean(find(y==max(y))))));

    %tmp  = (diff(y(end-round(d/100)*10:end)).^2);
    %stop = round(x(+d*10-(round(d/100)+1)*10+round(mean(find(tmp==min(tmp))))));

    tmp  = (diff(y(end-round(d/8)*10:end)).^1);
    stop = round(x(+d*10-(round(d/8)+1)*10+round(min(find(tmp<mean(tmp))))));

    %tmp = diff(y(end-10*round(d/8):end));
    %stop = round((min(find(tmp<mean(tmp)))+10*round(d/8))/10);
    
    if 0 % DEBUG
        figure
        plot(x,y)

        hold on
        plot(decay)
        plot([peak peak],[0 1],'r')
        plot([stop stop],[0 1],'r')
    end
