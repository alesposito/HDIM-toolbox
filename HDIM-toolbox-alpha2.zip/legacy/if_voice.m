% version 1.1: create ticId if not existing
%
% if_voice(msg,ticId,options)
% if_voice(msg,[],options)
% ticId = if_voice(msg,ticId,options)
% ticId = if_voice(msg,[],options)
%
% Send message to screen or to speakers
%
% ticId as ouput provide handler to new tic identifier
% ticId as input provide handler to old tic identifier
% ticId = [], used if no time limit is needed
%
% msg: message to be displayed
%
% options = [0]: print on screen (also options = [];
%            1 : on speakers
%            2 : on speakers if a time limit from earlier spoken message elapsed (t_lim = 30 seconds)
%                on screen otherwise

function varargout = if_voice(msg,ticId,options)
    t_lim = 30; % in seconds

    if isempty(options)
        options = 0;
    end
    
    if options==2 
        if isempty(ticId)
            ticId = tic;
            t_lim = 0;
        end
        
        t = toc(ticId);       
        if t>t_lim
            options = 1;
            ticId = tic;
        else
            options = 0;
        end
        varargout{1} = ticId;
    end
    
    switch options
        case 0
            display(['' msg]);
        case 1
            try
                tts(msg);
            catch
                display(['' msg]);
            end               
    end
    
    