% [G, S] = if_lifetime_phasors(im, t_bin, n_harmonic, omega)
% 
% Compute phasors (G,S) of order n_harmonic given a (time-domain) lifetime image im with data
%    collected in time bins of width t_bin and circular frequency omega
%
% [G, S] = if_lifetime_phasors(im, t_bin)
%   n_harmonic set to default (1) and omega computed by the decay; the period
%   is set equal to the time between the peak and the end of the decay
%
% if_lifetime_phasors(im, t_bin, n_harmonic, omega) or 
% if_lifetime_phasors(im, t_bin)
%   print information to screen
%
% REFERENCES
% Digman et al. (2007) Biophys J
% Redford and Clegg (2005) J Fluoresc
% Hanley and Clayton (2005) J Microsc
% Esposito et al. (2005) Biophys J
% Clayton et al. (2004) J Microsc
% Jameson and Gratton (1984) App Spec Rev
%
% CODED BY Alessandro Esposito (aesposito@quantitative-microscopy.org), 2007

function [G, S] = if_lifetime_phasors(im, t_bin, n_harmonic, omega, bTruncated)

    bDebug = 0;
    
% --- PARSING ---

    % Parse input
    if nargin==2
        n_harmonic=1;
        omega=0;
    elseif nargin~=2 & nargin~=5
        display([mfilename '> ERROR: illegal number of input arguments']);
        G=[]; S=[];
        return;
    end    

    % Parse output
    if nargout==0
        bPlot=1;
    else
        bPlot=0;
    end

% --- INITIALIZE GRAPHICS

    % find pre-existing figure where to plot phasors, othwewise initialize
    % a new one
    if bPlot
        h1 = max(findobj('Name','Phasors'));
        if isempty(h1)
            % draw universal circle
            h1 = figure('name','Phasors');
            plot((0:.01:1),sqrt(.5^2-((0:.01:1)-0.5).^2),'k')
            set(gca,'xlim',[0 1],'ylim',[0 1])
            str_col='.b'; 
            axis equal
            hold on
        else
            % check the colour of the last plot
            figure(h1)
            hc=get(gca,'children');
            last_colour = get(hc(1),'color');
            if last_colour(3)==1
                str_col='.r'; 
            else
                str_col='.b';        
            end
        end
    end % IF BPLOT
    
% --- COMPUTE PHASORS    

    % average decay
    decay_avg = mean(mean(im,1),2);                                 
    % set initial time to peak
    decay_ini = min(find(decay_avg(1:round(size(im,3)/2))==max(decay_avg(1:round(size(im,3)/2)))))+1;             
    % compute background level
    decay_bck = mean(decay_avg(1:round(decay_ini/2)))+3*std(decay_avg(1:round(decay_ini/2))); 
    % set end time where decay reaches background level
    decay_end = max(find(decay_avg>decay_bck));
    % initialize time bin values
    decay_t   = (0:size(im,3)-1) * t_bin;    
    
    % initial phase
    ph=omega*decay_t(decay_ini);
    
    % compute circular frequency if not assigned
    if omega==0
        omega = n_harmonic * 2*pi / max(decay_t);
    end
    
    if bTruncated
        im(:,:,1:decay_ini-1)=0;        
    end
    
    %dc = sum(im, 3)>20;
    %im = im .* repmat(dc,[1 1 size(im, 3)]);
    
    % compute phasors
    N = squeeze(sum(im,3))+eps;
    G = squeeze(sum(im.*repmat(reshape(cos(omega*decay_t-ph),[1 1 size(im,3)]),[size(im,1) size(im,2) 1]),3))./N;
    S = squeeze(sum(im.*repmat(reshape(sin(omega*decay_t-ph),[1 1 size(im,3)]),[size(im,1) size(im,2) 1]),3))./N;    


% --- BLOCK FOR DEBUGGING
    if bDebug
        [mean(G(:)) mean(S(:))]
        
        dbg_x = 2;
        dbg_y = 2;
        
        figure
        subplot(dbg_x,dbg_y,1)
        plot(t_val,decay_avg(ii,:))
        hold on
        plot(t_val(decay_ini:decay_end),decay_avg(ii,decay_ini:decay_end),'r')
        
        subplot(dbg_x,dbg_y,2)
        imagesc(N), axis image
        subplot(dbg_x,dbg_y,3)
        imagesc(G), axis image
        subplot(dbg_x,dbg_y,4)
        imagesc(S), axis image                
    end

% OUTPUT    
    if bPlot
        figure(h1);
        plot(G(:),S(:),str_col);
        set(gca,'xlim',[0 1],'ylim',[0 1])
    end

return