function err = if_parcomp(bStatus)

    try
        isOpen = matlabpool('size')>0;

        if ~isOpen & bStatus
            matlabpool local 4
        elseif isOpen & ~bStatus
            matlabpool close
        end
        
        err = 0;
    catch
        err = 1;
        if_voice('Parallel Computing Tollbox not installed',[],1);
    end
        