% Input Laser Comb and target anisotropy
% VERSION 4 (added parsing of laser comb file name)


%function HDIM_CAL = if_hdim_calibration_gui(HDIM_CAL)

laser_lines  = {'405nm','458nm','476nm','488nm','496nm','514nm','561nm','594nm','633nm'};
active_lines = zeros([1 length(laser_lines)]); % default laser lines to off
cn           = length(laser_lines);

% Parse laser comb name to identify active laser lines
idx = strfind(HDIM_CAL.files.spectral_comb,'_'); % identify line positions
n_active_lines = length(idx);

if n_active_lines>0
    for li=1:n_active_lines
        active = HDIM_CAL.files.spectral_comb(idx(li)+1:idx(li)+3);
        % serch line in list
        for ci=1:cn
            if strcmp(laser_lines{ci}(1:3),active)
               active_lines(ci) = 1;
               break 
            end
        end
    end
end


%% Spectral Comb GUI
scrsz=get(0,'ScreenSize');
yn = 200;
hf=figure('position',[scrsz(3)/2 scrsz(4)/2 100 yn],'menubar','none');
h=[];
for ci=1:cn
    h(ci)=uicontrol('style','checkbox','position',[10 yn-20-(ci-1)*(yn-25)/(cn+1) 100 10],'string',laser_lines{ci},'value',active_lines(ci));
    uicontrol('style','pushbutton','position',[10 10 80 20],'string','ok','callback','HDIM_CAL.Comb = if_hdim_calibration_clbk(h,hf);' );
end
uiwait(hf)

%% R target GUI
tmp = inputdlg('Which is the r target value?','HDIM',1,{'0'});
HDIM_CAL.Info.r_target = repmat(str2double(tmp{1}), [1 length(HDIM_PAR.SpElements)]);

clear tmp h hf scrsz yn cn laser_lines ci