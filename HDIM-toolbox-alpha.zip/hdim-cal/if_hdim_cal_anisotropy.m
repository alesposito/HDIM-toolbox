% VERSION 5 - get name from HDIM_CAL

function [HDIM_PAR, HDIM_CAL, img] = if_hdim_cal_anisotropy(HDIM_PAR, HDIM_CAL)
    
    filepath   = HDIM_CAL.files.path;
    files2load = HDIM_CAL.files.anisotropy;
    
    thr = 5; % threshold to identify low confidence pixels @@@ add as an optional parameter
    h1 = fspecial('disk', 10); % used to smooth G-factors
    %h2 = fspecial('disk', 1); % used to smooth Illuminations
    
    if ~iscell(files2load)
       files2load = {files2load};
    end
    
    for i=1:length(files2load)
        switch lower(files2load{i}(end-2:end))
            case 'mat'
                load([filepath files2load{i}]);
            case 'sdt'
                img = if_bh_loadsdt([filepath files2load{i}]);
            otherwise
                display([mfilename '> FILE FORMAT NOT SUPPORTED'])
        end  
                
        if ~exist('tmp2')
            tmp2 = zeros(size(img));
        end
        tmp2 = tmp2 + img;
    end
    img = tmp2;
    clear tmp2;
    
    r1 = [];
    G  = [];
    r2 = [];
    %h = fspecial('gaussian', hsize, sigma);            
    
    %% compute calibration on spectral data (not considering spatial dimension
    dc   = reshape(sumch(img,4),[size(img,1) size(img,2) length(HDIM_PAR.SpElements) 2]);   % photon counts (non time resolved)
    sp1  = sumch(dc(:,:,HDIM_PAR.SpElements,1),[1 2]);                                      % spectrum in parallel orientation
    sp2  = sumch(dc(:,:,HDIM_PAR.SpElements,2),[1 2]);                                      % spectrum in perpendicolar direction
    
    % v4.0
    %sp2c = interp1(HDIM_CAL.a_wav2,sp2,HDIM_CAL.a_wav1,'linear','extrap')';                 % spectrum in perpendicular direction interpolated to WAV1 vector
    
    % v4.1 - removing extrapolation (v4.0) and only using interpolation. APPLY CAL routines updated accordingly
    sp1_ = sp1; % memo val
    sp2_ = sp2; % memo val
    sp1  = interp1(HDIM_CAL.a_wav1,sp1,HDIM_CAL.a_wav0,'linear')';                 % spectrum in par direction interpolated to WAV0 vector
    sp2  = interp1(HDIM_CAL.a_wav2,sp2,HDIM_CAL.a_wav0,'linear')';                 % spectrum in per direction interpolated to WAV0 vector
    
    r1   = (sp1-sp2)./(sp1+2*sp2+eps);                                                    % uncorrected anisotropy (using interpolated sp2)
    Gav  = (sp1./sp2) .* ((1-HDIM_CAL.Info.r_target)./(1+2*HDIM_CAL.Info.r_target))';     % G-factor (spatially invariant, spectrally dependent)        
    
    thr = prod([sizech(img,[1 2]) thr]);                                                  % update threshold for non spatially resolved computations 
    idx = (sp2+sp1)>thr;                                                                  % identify spectral elements with sufficient photoncounts
    Gav = interp1(HDIM_CAL.a_wav1(idx),Gav(idx),HDIM_CAL.a_wav1,'cubic','extrap')';       % G factrors corrected for low intensity pixels        @@@ add as an option
    r2   = (sp1-Gav.*sp2)./(sp1+2*Gav.*sp2+eps);                                          % corrected anisotropy values
     
    Gav = smooth1d(Gav,1);
    %% compensation for illumination uneveness @@@ add as an option
    HDIM_CAL.IL = sumch(dc,[3 4]);
    HDIM_CAL.IL = HDIM_CAL.IL./mean(HDIM_CAL.IL(:));
    HDIM_CAL.IL = medfilt2(HDIM_CAL.IL,[3 3]);
    %HDIM_CAL.IL = imfilter(HDIM_CAL.IL,h2,'symmetric');
    
    %% generate a 3D G-factor maps. The assumption used in the following code is that spatial differences are spectrally invariant
    I1          = imfilter(sumch(dc(:,:,HDIM_PAR.SpElements,1),[3 4]),h1,'replicate');      % Image, parallel polarization
    I2          = imfilter(sumch(dc(:,:,HDIM_PAR.SpElements,2),[3 4]),h1,'replicate');      % Image, perpendicolar direction
    R1          = (I1-I2)./(I1+2*I2+eps);                                                   % uncorrected anisotropy    
    r_target    = sum((sp1+2*Gav.*sp2)'.*HDIM_CAL.Info.r_target)/sum((sp1+2*Gav.*sp2));     % recompute target r-value (consider brigthness of individual channel)
    G2          = (I1./I2) .* ((1-r_target)./(1+2*r_target));                               % G-factor (spatially resolved, spectrally invariant)    
    correction  = G2./mean(G2(:));                                                          % estimate spatial correction to apply to Gav
    
    % Fully calibrate in space and spectral dimension
    HDIM_CAL.G  = repmat(correction,[1 1 HDIM_PAR.s_dim]).*shiftdim(repmat(Gav,[1 size(img,1) size(img,2)]),1);    
                
    %% DEBUG
    if 1
        figure
        subplot(1,2,1)
        plot(HDIM_CAL.a_wav1,sp1_,'b')
        hold on
        plot(HDIM_CAL.a_wav0,sp1,'b--')
        plot(HDIM_CAL.a_wav1,sp2_,'r')
        plot(HDIM_CAL.a_wav0,sp2,'r--')
        legend({'par','par interp','per','per interp'})
        
        subplot(1,2,2)
        plot(HDIM_CAL.a_wav0,r1,'k')
        hold on
        plot(HDIM_CAL.a_wav0,Gav,'b')
        plot(HDIM_CAL.a_wav0,r2,'r')
        legend({'Anisotropy (precalibration)','G value','Anisotropy (post-calibration)'})        
    end
    
    


