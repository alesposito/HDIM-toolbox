% VERSION 3 - get name from HDIM_CAL
% SPECTRAL CALIBRATION WITH LASER COMB
function [HDIM_PAR, HDIM_CAL, img] = if_hdim_cal_spectral(HDIM_PAR, HDIM_CAL)
    
    file = [HDIM_CAL.files.path HDIM_CAL.files.spectral_comb]

    switch lower(file(end-2:end))
        case 'mat'
            load(file);
        case 'sdt'
            img = if_bh_loadsdt(file);
        case 'txt'
            [Ipar,Iper]=if_SPAD_laserPeakAnalysis(file);
            img(1,1,1:length(Ipar)*2,1) = [Ipar,Iper];
        otherwise
            display([mfilename '> FILE FORMAT NOT SUPPORTED'])
    end            
    
    linear = questdlg('Is the spectrograph providing linear or non-linear dispersion?', 'HDIM', 'Linear','Non-linear','Linear');
    if strcmp(linear,'Linear')
        lin = 1;
    else
        lin = 2;
    end

%%
    sp_lines    = HDIM_CAL.Comb;
    sp_elements = HDIM_PAR.SpElements;
    
        
    % ROI definition @@@currently not used, but perhaps ROI definition by GUI
    % needed in the future
    ROI={[1 size(img,1) 1 size(img,2)]};
    ri = 1;
    spectra = reshape(sumch(img(ROI{ri}(1):ROI{ri}(2),ROI{ri}(3):ROI{ri}(4),:,:),[1 2 4]),[length(HDIM_PAR.SpElements) 2]);

    n_lines    = length(sp_lines);

    %%% THIS CODE WAS ADDED FOR V2 of HDIM %%%%%%
    new_sp_elements = (1:.1:length(HDIM_PAR.SpElements));
    spectra = interp1(sp_elements,spectra,new_sp_elements);
    sp_elements = new_sp_elements;    
    %%%%%%%%%%%%%%%%
    
    % compute initial values: fraction
    x01 = repmat(.1/n_lines,[n_lines 1]);
    
    % compute initial values: position
        x02_1 = spectra(:,1)>1*mean(spectra(:,1));
        x02_2 = spectra(:,2)>1*mean(spectra(:,2));

        %for j=2:size(spectra,1)
        %    if x02_1(j-1)&x02_1(j), x02_1(j) = 0; end
        %    if x02_2(j-1)&x02_2(j), x02_2(j) = 0; end
        %end

        tmp = (bwmorph(repmat(x02_1,[1 size(x02_1)]),'skel',Inf)); 
        x02_1= (tmp(:,round(size(x02_1,1)/2)));
        tmp = (bwmorph(repmat(x02_2,[1 size(x02_2)]),'skel',Inf)); 
        x02_2= (tmp(:,round(size(x02_2,1)/2)));
        clear tmp

        x02_1 = sp_elements(x02_1==1)'; 
        x02_2 = sp_elements(x02_2==1)'; 

    %     if size(x02_1,1)~=n_lines, x02_1 = (2:11/(n_lines-1):13)'; end % TODO change with 64
    %     if size(x02_2,1)~=n_lines, x02_2 = (2:11/(n_lines-1):13)'; end % TODO change with 64
        if size(x02_1,1)~=n_lines, x02_1 = (2:(length(HDIM_PAR.SpElements)-3)/(n_lines-1):length(HDIM_PAR.SpElements)-1)'; end % TODO check if narrow enough
        if size(x02_2,1)~=n_lines, x02_2 = (2:(length(HDIM_PAR.SpElements)-3)/(n_lines-1):length(HDIM_PAR.SpElements)-1)'; end % TODO check if narrow enough
        
    x03 = ones(n_lines,1);    % width
    
    x0_1  = [reshape([x01 x02_1 x03]',[1 3*n_lines]) eps];    
    x0_2  = [reshape([x01 x02_2 x03]',[1 3*n_lines]) eps];    
    
    xl  = [repmat([0 0  0 ],[1 n_lines]) 0];
    xh  = [repmat([1 length(HDIM_PAR.SpElements)+1 length(HDIM_PAR.SpElements)+1],[1 n_lines]) 1];
    
    clear x01 x02_1 x02_2 x03

    % fit laser lines to measured spectra
    sp1 = spectra(:,1)/sum(spectra(:,1));
    sp2 = spectra(:,2)/sum(spectra(:,2));
    
    options = optimset('MaxFunEvals',10000,'MaxIter',10000,'tolfun',10e-12,'tolx',10e-12,'display','off', 'PrecondBandWidth', Inf);
    p1 = lsqcurvefit(@if_regfun_polygaus, x0_1, sp_elements, sp1', xl, xh,options);
    p2 = lsqcurvefit(@if_regfun_polygaus, x0_2, sp_elements, sp2', xl, xh,options);
    
    % generate calibration curve
    pp1 = reshape(p1(1:end-1),[3 n_lines]);
    pp2 = reshape(p2(1:end-1),[3 n_lines]);
    b1  = polyfit(pp1(2,:),sp_lines,lin);
    b2  = polyfit(pp2(2,:),sp_lines,lin);

    % compute resolution
    if lin==1 % spectrograph resolution is linear
        lines_in_nm1=pp1(3,:)*b1(1);
        lines_in_nm2=pp2(3,:)*b2(1);
    else % spectrograph resolution is nonlinear
        end1=polyval(b1,pp1(2,:)+pp1(3,:));
        beg1=polyval(b1,pp1(2,:)-pp1(3,:));
        end2=polyval(b1,pp2(2,:)+pp2(3,:));
        beg2=polyval(b1,pp2(2,:)-pp2(3,:));
        lines_in_nm1=end1-beg1;
        lines_in_nm2=end2-beg2;
    end

    b3 = polyfit(sp_lines,lines_in_nm1,1);
    b4 = polyfit(sp_lines,lines_in_nm2,1);
    res1_avg = mean(lines_in_nm1);
    res1_err = std(lines_in_nm1);
    sp1_minv = polyval(b1,sp_elements(1));
    sp1_maxv = polyval(b1,sp_elements(end));
    sp1_band = sp1_maxv-sp1_minv;
    res2_avg = mean(lines_in_nm2);
    res2_err = std(lines_in_nm2);
    sp2_minv = polyval(b2,sp_elements(1));
    sp2_maxv = polyval(b2,sp_elements(end));
    sp2_band = sp2_maxv-sp2_minv;
    
    % Update data structure
    HDIM_CAL.Sp1 = b1;
    HDIM_CAL.Sp2 = b2;
    
    HDIM_PAR.Sp1Band = [sp1_minv sp1_maxv];
    HDIM_PAR.Sp1Res  = sp1_band/length(HDIM_PAR.SpElements);
    HDIM_PAR.Sp2Band = [sp2_minv sp1_maxv];
    HDIM_PAR.Sp2Res  = sp2_band/length(HDIM_PAR.SpElements);

    % Elements to be included in the analysis
    HDIM_PAR.s_ele = HDIM_PAR.SpElements;
    HDIM_PAR.s_dim = size(HDIM_PAR.s_ele,2); % total spectral channels
    HDIM_PAR.idx_par = HDIM_PAR.s_ele+HDIM_PAR.s_dim*(HDIM_PAR.ChPar-1);
    HDIM_PAR.idx_per = HDIM_PAR.s_ele+HDIM_PAR.s_dim*(HDIM_PAR.ChPer-1);
    HDIM_CAL.a_wav1 = if_hdim_spe2wav(HDIM_CAL, HDIM_PAR.s_ele, 1);
    HDIM_CAL.a_wav2 = if_hdim_spe2wav(HDIM_CAL, HDIM_PAR.s_ele, 2);       
    HDIM_CAL.a_wav0 = if_hdim_spe2wav(HDIM_CAL, HDIM_PAR.s_ele, 0); % interpolating vector

    %% display results
figure
    subplot(2,2,1)
    plot((sp_elements(1):0.1:sp_elements(end)),if_regfun_polygaus(p1, (sp_elements(1):0.1:sp_elements(end))),'k')
    hold on
    plot((sp_elements(1):0.1:sp_elements(end)),if_regfun_polygaus(p2, (sp_elements(1):0.1:sp_elements(end))),'--b')
    plot(sp_elements,sp1,'ok')
    plot(sp_elements,sp2,'ob')
    xlabel('spectral element (#)');
    ylabel('normalized intensity (a.u.)');
    title('laser comb fit');
    set(gca,'xlim',[sp_elements(1) sp_elements(end)])
        
    subplot(2,2,2)
    plot(pp1(2,:),sp_lines,'ok')
    hold on
    plot(pp2(2,:),sp_lines,'ob')
    plot(sp_elements,polyval(b1,sp_elements),'k')
    plot(sp_elements,polyval(b2,sp_elements),'b')
    xlabel('spectral element (#)');
    ylabel('wavelength (nm)');
    title('spectral calibration');    
    set(gca,'xlim',[sp_elements(1) sp_elements(end)])
  
    subplot(2,2,3)
    plot(sp_lines,lines_in_nm1,'ok')
    hold on
    plot(sp_lines,lines_in_nm2,'ob')
    plot(sp_lines,polyval(b3,sp_lines),'--k')
    plot(sp_lines,polyval(b4,sp_lines),'--b')
    plot(sp_lines,repmat(res1_avg,[1 length(sp_lines)]),'k')
    plot(sp_lines,repmat(res2_avg,[1 length(sp_lines)]),'b')
    xlabel('spectral element (#)');
    ylabel('resolution (nm)');
    title('spectral resolution');    
    set(gca,'xlim',[sp_lines(1) sp_lines(end)])
    
    subplot(2,2,4)    
    text(-0.1,1,['spectral resolution: ' num2str(res1_avg,'%2.1f') '+-' num2str(res1_err,'%2.1f') ' nm'],'color','k');
    text(-0.1,0.86,['spectral band (min/max, nm): ' num2str(sp1_minv,'%2.1f') '/' num2str(sp1_maxv,'%2.1f') ],'color','k');
    text(-0.1,0.72,['spectral band: ' num2str(sp1_band,'%2.1f') ' nm'],'color','k');
    text(-0.1,0.58,['band/channel: ' num2str(HDIM_PAR.Sp1Res ,'%2.1f') ' nm'],'color','k');
    text(-0.1,0.44,['spectral resolution: ' num2str(res2_avg,'%2.1f') '+-' num2str(res2_err,'%2.1f') ' nm'],'color','b');    
    text(-0.1,0.30,['spectral band (min/max, nm): ' num2str(sp2_minv,'%2.1f') '/' num2str(sp2_maxv,'%2.1f') ],'color','b');
    text(-0.1,0.16,['spectral band: ' num2str(sp2_band,'%2.1f') ' nm'],'color','b');
    text(-0.1,0.02,['band/channel: ' num2str(HDIM_PAR.Sp2Res ,'%2.1f') ' nm'],'color','b');
    axis off
