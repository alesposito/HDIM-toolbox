if 1 %%%%% WARNING TEMPORAL CALIBRATION TEMPORARILY SUPPRESSED
    %%
    file = [file_path3 file_name3];
    switch lower(file(end-2:end))
        case 'mat'
            load(file);
        case 'sdt'
            [img, hdr, asc, TCSPC, msd] = if_bh_loadsdt(file);
        otherwise
            display([mfilename '> FILE FORMAT NOT SUPPORTED'])
    end

    %%
    decays = sumch(reshape(img,[size(img,1) size(img,2) size(img,3)/2 2 size(img,4)]),[1 2 3])';
    if 1
        figure
        plot(decays)
        hold on
        %plot(diff(decays))
    end
    
    %%
% define regions of the decay, start, peak, end
figure
for i=1:2
    pek = find(diff(decays(:,i))==max(diff(decays(:,i))))+1;
    ini = find(decays(:,i)==min(nonzeros(decays(1:pek,i))));
    
    stp = max(find((decays(:,i)>mean(decays(:,i)))))
    
    decays(:,i) = decays(:,i)/max(decays(:,i));
    subplot(1,2,i)
    plot((1:64),decays(:,i))
    hold on
    line([ini ini],[0 1],'color','k','linestyle','--')
    line([stp stp],[0 1],'color','k','linestyle','--')
end

% search for maximum overlapping @@@ this section could be recoded...
% currently wokring numerically, not amazingly elegant, but works
figure
    k = 30 % kernel for resampling
    a = interp1((1:64),decays(:,1),(1:1/k:64))';
    b = interp1((1:64),decays(:,2),(1:1/k:64))';
    mk = a>0 & b>0;
    o = []    
    subplot(3,1,1)
    for i=-2*k:2*k
        r = (a-circshift(b,i))./(circshift(b,i)+a);
        r = (mk(pek*k-3*k:pek*k+4*k).*r(pek*k-3*k:pek*k+4*k));
        plot(r)
        o(i+2*k+1)=sum(abs(r))
        hold on
        drawnow
    end
    
    subplot(3,1,2)
    plot((-2*k:2*k),o);
    
    subplot(3,1,3)
    i = find(o==min(o))-2*k-1;
    a = decays(:,1);
    b = interp1((1:64),decays(:,2),(1:64)-i/k);
    plot(a,'k')
    hold on
    plot(b,'r')

    % update dats structure
    % @@@ import tacres and 64 explicetly
    t_bin = 1E9*if_lifetime_bhpar(TCSPC,'SP_TAC_R')/(if_lifetime_bhpar(TCSPC,'SP_TAC_G')*if_lifetime_bhpar(TCSPC,'SP_ADC_RE'));
    HDIM_CAL.Time = t_bin*i/k;
    
    %% Check Calibration  
    bCalibrating = 0;
    if_load_bh_spc2
    %%
    decays2 = squeeze(sum(reshape(sum(sum(img,1),2),[16 2 16]),1))';
    spectra = squeeze(sum(reshape(sum(sum(img,1),2),[16 2 16]),3));
    r = (spectra(:,AE_CHDEF_PPAR)-G.*spectra(:,AE_CHDEF_PPER))./(spectra(:,AE_CHDEF_PPAR)+2*G.*spectra(:,AE_CHDEF_PPER));
    
    figure
    subplot(1,3,1)
    plot(decays2)
    %@@@ AXIS WITH TIMIGN
    
    subplot(1,3,2)
    plot(polyval(HDIM_CAL.Sp1,sp_elements),spectra(:,1),'b')
    hold on
    plot(polyval(HDIM_CAL.Sp2,sp_elements),spectra(:,2),'g')
    set(gca,'xlim',HDIM_PAR.Sp2Band)
    xlabel('wavelength (nm)')
    
    subplot(1,3,3)
    plot(polyval(HDIM_CAL.Sp1,sp_elements),r)
    set(gca,'xlim',HDIM_PAR.Sp2Band)
    xlabel('wavelength (nm)')
end %%%% TEMP CAL SUPPRESSED