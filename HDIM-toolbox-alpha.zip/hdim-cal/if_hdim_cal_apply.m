% VERSION 6.2
% Correct for G-value, uneven illumination and time/spectral registration
%
% img = if_hdim_cal_apply(img, HDIM_CAL, HDIM_PAR, 'option name','option value', ...)
%
% OPTION NAME                    POSSIBLE VALUE [DEFAULT]     DESCRIPTION
% 'lit' or 'light correction'    1 or 0 [1]                   Apply correction of uneven illumination (HDIM_CAL.IL)
% 'reg' or 'registration'        1 or 0 [1]                   Apply correction of spectral/time shifts
% 'dlg' or 'dialog'              1 or 0 [0]                   Interactive mode ON/OFF
% 'gun' or 'g-uneven'            1 or 0 [1]                   If '1' apply pixel-by-pixel correction, otherwise apply
%                                                             spatially invariant G factor
% 'opt' or 'options'             [0/1 0/1 0/1] def: [1 1 0]   Input all the above parameters as an array
% 'vrb' or 'verbose'             0 off 1 display 2 speach [1] Set verbose state Off / print on screen / speach
% 'msk'                          []/2D mask                   Apply calibration only to mask, other pixels set to eps
%
% 6.2 follows if_hdim_cal_anisotropy 4.1, changing from extrapolation to intrapolation only
% 6.2 provides better verbose response and elapsed time estimates
% 6.2 includes 'gun' option
% 6.3 include option to apply calibration only to non-masked pixels. Masked pixels set to eps

function img = if_hdim_cal_apply(img, HDIM_CAL, HDIM_PAR, varargin)

    % apply default values
    bLit = 1; 
    bReg = 1; 
    bDlg = 0; 
    bVrb = 1;
    bGun = 1;
    bMsk = 0;
     msk = ones(sizech(img,[1 2]));
     
    if nargin>3
       for i=1:length(varargin)/2
           switch  lower(varargin{2*i-1})
               case {'lit','light correction'}
                    bLit = varargin{2*i};
               case {'reg','registration'}
                    bReg = varargin{2*i};
               case {'dlg','dialog'}
                    bDlg = varargin{2*i};
               case {'vrb','verbose'}
                    bVrb = varargin{2*i};    
               case {'gun','g-uneven'}
                    bGun = varargin{2*i};                        
               case {'options'}    
                   bLit = varargin{2*i}(1);
                   bReg = varargin{2*i}(2);
                   bDlg = varargin{2*i}(3);
               case {'msk'}
                   if ~isempty(varargin{2*i})
                       bMsk = 1;
                       msk  = varargin{2*i};                         
                   end
                       
           end
       end
    end

    
    
    
    idx_per = HDIM_PAR.SpElements(end)*(HDIM_PAR.ChPer-1)+HDIM_PAR.SpElements;

    % background illumination correction
    if bLit & isfield(HDIM_CAL,'IL') 
        img = img ./ repmat(HDIM_CAL.IL/max(HDIM_CAL.IL(:)),[1 1 size(img,3) size(img,4)]);
    end
    
    % fix back compatibility issue
    if  prod(size(repmat(HDIM_CAL.G,[1 1 1 size(img,4)])))~=prod(size(img(:,:,idx_per,:))) 
        HDIM_CAL.G = (shiftdim(repmat(HDIM_CAL.G,[1 size(img,1) size(img,2)]),1));
    end
    

    if bReg
       if bDlg 
            beep
            ANS = questdlg('Spectral/Time registration can require several minutes of computation. Are you sure you would like to continue? Pressing no will cancel registration, but keep the rest of the code running.','HDIM','Yes') ;
       else
            ANS = 'yes'; 
       end
       if strcmp(lower(ANS),'yes')                  
           %% REALIGN SECOND TO FIRST CHANNEL
           display('Computing...')
          
           nt        = size(img,4);
           
           % Shape matrix
           img_per = img(:,:,HDIM_PAR.idx_per,:);
           img(:,:,HDIM_PAR.idx_per,:) = [];     
           img_par = img(:,:,HDIM_PAR.idx_par,:); 
           clear img
           
           % collpase 2d x-y into a single spatial axis
           img_par = reshape(img_par,...
                      [HDIM_PAR.x_dim*HDIM_PAR.y_dim sizech(img_par,[3 4])]); 
           img_per = reshape(img_per,...
                      [HDIM_PAR.x_dim*HDIM_PAR.y_dim sizech(img_per,[3 4])]);  

           % select only pixels within mask, set the other to eps
           msk_idx = find(reshape(msk,[HDIM_PAR.x_dim*HDIM_PAR.y_dim 1]));
           msk_len = size(msk_idx,1);       
           img_par = img_par(msk_idx,:,:);
           img_per = img_per(msk_idx,:,:);
                  
           % Generate axis
           W1 = HDIM_CAL.a_wav1;
           W2 = HDIM_CAL.a_wav2;
           D = msk_idx;
           T = HDIM_PAR.t;           
           
           WI = HDIM_CAL.a_wav0;
           DI = msk_idx;                    % no shift in the spatial direction
           TI = HDIM_PAR.t - HDIM_CAL.Time;
           
           % Initialize interpolation algorithm
           brick_len = 5000;
           data_len  = size(D,1);
           brick_num = ceil(data_len/brick_len);
           
           % Interpolate
           ticId = tic;
           ticId_Vrb = ticId;
           hw = waitbar(0,'Interpolating image');
           
           for ib=1:brick_num
               if ib<brick_num
                   brick_idx = (ib-1)*brick_len+1:ib*brick_len;                
               else
                   brick_idx = (ib-1)*brick_len+1:data_len;                
               end
               
               img_per(brick_idx,:,:) = interp3(W2, D(brick_idx), T, img_per(brick_idx,:,:), WI, DI(brick_idx), TI,'line',NaN);               
               img_par(brick_idx,:,:) = interp3(W1, D(brick_idx), T, img_par(brick_idx,:,:), WI, DI(brick_idx), T, 'line',NaN);
               
               elt = toc(ticId)/60;
               est = elt*(brick_num/ib-1);
               if floor(est)==0
                   msg = [num2str(round(est*60),'%2.0f') ' seconds'];
               else
                   msg = [num2str(est,'%2.1f') ' minutes'];
               end
               ticId_Vrb = if_voice(msg,ticId_Vrb,2);
               waitbar(ib/brick_num,hw,['Elapsed: ' num2str(elt,'%2.2f') 'mins; Remaining: ' num2str(est,'%2.2f') 'mins']);
           end           
           
           close(hw)
           clear W D T WI DI TI           
          
           % restore original dimension trying to save some memory
           img = [];
           tmp = zeros([HDIM_PAR.x_dim*HDIM_PAR.y_dim size(HDIM_PAR.idx_par,2) nt])+eps;
           tmp(msk_idx,:,:) = img_par;
           img = tmp;
           clear img_par
           tmp = zeros([HDIM_PAR.x_dim*HDIM_PAR.y_dim size(HDIM_PAR.idx_par,2) nt])+eps;
           tmp(msk_idx,:,:) = img_per;
           clear img_per
           img(:,size(HDIM_PAR.idx_per,2)+1:size(HDIM_PAR.idx_per,2)*2,:) = tmp;
           clear tmp           
           img = reshape(img,[HDIM_PAR.x_dim HDIM_PAR.y_dim 2*size(HDIM_PAR.idx_par,2) nt]);
           display('Time/spectral registration completed.')
           
           %% FIX isnan and isinf,, this should be improved working on interp3 optimization
           idx      = find(isnan(img) | isinf(img));
           img(idx) = 0;
           %[i1 i2 i3 i4] = ind2sub(size(img),idx);
           %HDIM_VIS.msk_2d(i1,i2)   = 0;
           %HDIM_VIS.msk_hd(i1,i2,:) = 0;
       end
    end
    
    % APPLY G-FACTOR CORRECTION (6.1, in 6.0 this line was before the interpolation block)
    if bGun
        img(:,:,idx_per,:) = repmat(HDIM_CAL.G,[1 1 1 size(img,4)]).*img(:,:,idx_per,:);
    else
        img(:,:,idx_per,:) = repmat(shiftdim(repmat(sumch(HDIM_CAL.G,[1 2])/(HDIM_PAR.x_dim*HDIM_PAR.y_dim),[1 HDIM_PAR.x_dim HDIM_PAR.y_dim]),1),[1 1 1 size(img,4)]).*img(:,:,idx_per,:);;
    end
