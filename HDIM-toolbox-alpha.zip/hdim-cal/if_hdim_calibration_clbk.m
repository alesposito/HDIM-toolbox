function sel = if_hdim_calibration_clbk(h,hf)
     
    sel=[];
    c=0;
    for ci=1:length(h)        
        if get(h(ci),'value')
            tmp = get(h(ci),'string');
            c = c +1;
            sel(c) = str2num(tmp(1:3));
        end
    end
    
    close(hf)