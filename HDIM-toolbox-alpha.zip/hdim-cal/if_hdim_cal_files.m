function files = if_hdim_cal_files

    file_types = '*.mat;*.sdt';        
    
    % Spectral calibration
    [file_name1 file_path1] = uigetfile(file_types,'Select a file obtained with a spectral comb...');
    
    cd(file_path1)
    
    % Anisotropy calibration
    display('Files for anisotropy calibration (e.g. white LED light) will be used also for compensation of uneven pixel dwell time for the Leica SP5)')
    [file_name2 file_path2] = uigetfile(file_types,'Select one or more files for anisotropy calibration...','MultiSelect','on');
    
    % Time regritration
    display('Press "cancel" to skip time registration')
    [file_name3 file_path3] = uigetfile(file_types,'Select a file for time registration (e.g., fluorescin sample...','MultiSelect','on');
    if ~ischar(file_name3)
       files.bTime = 0;
    else
       files.bTime = 1; 
    end
        
    % Dark counts compensation
   % display('Press "cancel" to skip dark count compensation')
   % [file_name4 file_path4] = uigetfile(file_types,'Select a file for dark counts compensations...');
   % if ~ischar(file_name4)
   %        files.bDark = 0;
   %     else
   %        files.bDark = 1; 
   % end
    
    % Save to
    [save_name save_path  ] = uiputfile('*.mat','Save as (calibration file)...');

    
    if ~strcmp(file_path1,file_path2) | ~strcmp(file_path1,file_path3) | ~strcmp(file_path1,save_path)
        error('Currently files for calibration should be within the same folder')
    end
    
    % PATHS
    files.path          = file_path1; % Main path for loading
    files.save_path     = save_path;  % Path for saving
    
    % FILES
    files.spectral_comb = file_name1; % Spectral comb
    files.anisotropy    = file_name2; % Anisotropy and illumination homogeneity calibration
    files.time          = file_name3; % Time registration
    %files.dark_counts   = file_name4; % Dark counts
    files.calibration   = save_name;  % Calibration file to be saved
    
    
    
    