function y = if_regfun_polygaus(b,x)
    n = round((size(b,2)-1)/3);
    y = b(end);    
    for i=1:n
        y = y + b(1+3*(i-1)).*exp(-((x-b(2+3*(i-1)))./b(3+3*(i-1))).^2);
    end
    

    
