% evaluate size along a set of specified dimensions

function varargout = sizech(i,d)
       
    o = zeros([1 length(d)]);
    
    for di=1:length(d)
        o(di) = size(i,d(di));
    end
    
    if nargout<=1
        varargout{1} = o;
    else
        if nargout~=length(o)
            error([mfilename '> number of output arguments do not match requested number of dimensions'])
        end
        for  di=1:nargout
            varargout{di} = o(di);
        end
    end