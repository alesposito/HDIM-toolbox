legacy files are those script that belong to the larger ImFluo software package in use in the laboratory of A. Esposito and that are needed to run HDIM-toolbox, although formally not an integral part of it.

