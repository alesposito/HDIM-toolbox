% VERSION 5


% INIT
clear all
close all
HDIM_PAR = [];

%% INIT
% Options - analysis
bExcludeBackground    = 1; % Exclude background from training set
bNorm                 = 0; % Brigthness normalization
bReduce               = 1   ; % Data reduction 
bMaskResults          = 1; % Apply mask to results
bRobust               = 0; % Robust PCA algorithm (obsolete)

ExtractionType        = 1;     % 1:PCA, 2:PCA Robust, 3: TICA
n_comp                = 3; 
thr                   = 5;   % minimum number of photons in each individual spectral/pol channel
DSP_KRN               = [2 2]; % median filtering kernel for displayed images

% Options -calibration
bLightFieldCorrection = 0; % Correct for uneven illumination/detection
bGun                  = 0; % 1 to correct for spatially variant G

% Options - save/load
bIOprojections        = 0; % 0: no IO, 1: load (do not use pca_compute or kmeans_compute), 2: save results
bSummarySave          = 1; % Save Result Images
bPCA_SaveOriginal     = 0; % Backup original image during PCA

% Options - Others
bFilter_Display = 1;  % filter deisplayed images
bParComp        = 0;  % parallel computing on/off (not supportet yet, must restyle cal_apply)
bVoice          = 2;  % 0 no, 1 yes, 2 auto
bBatch          = 1;  % BATCH PROCESSING (not implemented yet) @@@ currently only overriding queries
BATCH_OPTS      = []; % NOT IMPLEMENTED YET @@@

% Options - DATA BLOCK DEFINITIONS
n  = 15000;      % number of pixels to be included in the training set
n2 = 10000;      % kernel for projections (length of individual pixel-blocks)

% --- --- --- START --- --- ---

%% LOAD
if bIOprojections==1
    [load_name_pca load_path_pca] = uigetfile('*.mat','PCA/K-means coefficients...');
end

[img HDIM_CAL HDIM_PAR HDIM_VIS, HDIM_CST] = if_hdim_load(HDIM_PAR);    

%% Initializations

% Parallel Computing
if ~if_parcomp(bParComp)
    HDIM_PAR.PC = bParComp; 
else
    HDIM_PAR.PC = 0;
    if_parcomp(0);
end

% Display management
HDIM_PAR.filter_display.status = bFilter_Display;
HDIM_PAR.filter_display.kernel = DSP_KRN;

% Verbose management
HDIM_PAR.Verbose = bVoice;   
if ~isfield(HDIM_PAR.h,'ticVb') & HDIM_PAR.Verbose
    HDIM_PAR.h.ticVb = tic;
end

% refresh HDIM_CAL and HDIM_PAR
[HDIM_CAL HDIM_PAR] = if_hdim_getdimensions(img, HDIM_CAL, HDIM_PAR);

% Generate mask (does not operate along time dimension and anisotorpy, but only space and colour)
HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR);

% apply calibration
img = if_hdim_cal_apply(img, HDIM_CAL, HDIM_PAR, 'options', [1 1 ~bBatch],'g-uneven',bGun,'msk',HDIM_VIS.msk_2d);

% Renew mask
HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR);

HDIM_PAR.h.ticVb = if_voice('Dataset registered',HDIM_PAR.h.ticVb,HDIM_PAR.Verbose);

%%
if_hdim_overview;
HDIM_PAR.h.ticVb = if_voice('Overview completed',HDIM_PAR.h.ticVb,HDIM_PAR.Verbose);



%% --- PCA COMPUTATION BLOCK ---
% PCA initialization
[img dc] = if_hdim_pca_reshape(img,HDIM_PAR,'Reduce',bReduce,...
                                            'Normalize',bNorm,...
                                            'Save Original',bPCA_SaveOriginal,...
                                            'Direction','Forward');
if_hdim_pca_compute

HDIM_PAR.h.ticVb = if_voice('PCA done, now projecting the rest of the dataset',HDIM_PAR.h.ticVb,HDIM_PAR.Verbose);

%%
if_hdim_pca_apply

%% reshape back
prj = reshape(prj,[HDIM_PAR.x_dim HDIM_PAR.y_dim size(prj,2)]);
img = reshape(img,[HDIM_PAR.x_dim HDIM_PAR.y_dim size(prj,3)]);
dc  = reshape(dc, [HDIM_PAR.x_dim HDIM_PAR.y_dim]);

% --- END PCA COMPUTATION BLOCK ---


%% DISPLAY
% PCA projections
HDIM_PAR = if_hdim_pca_show(prj,n_comp,HDIM_PAR, HDIM_CAL, HDIM_VIS); 

%% morphology
mrp = 1-if_hdim_pca_stretch(dc, HDIM_VIS.msk_2d, 'std');
HDIM_PAR.h.figs.morphology = figure('name',['Morphology (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
imshow(imadjust(mrp,[0.2 1]));
title('morphology');

%% display digital DAB
if_hdim_pca_rgb2dab

HDIM_PAR.h.ticVb = if_voice('PCA anaylysis completed',HDIM_PAR.h.ticVb,HDIM_PAR.Verbose);

