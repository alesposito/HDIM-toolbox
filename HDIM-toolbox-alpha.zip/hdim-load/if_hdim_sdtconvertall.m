function if_hdim_sdtconvert
%%    
    thr = 5;
    bLightFieldCorrection = 1; % Correct for uneven illumination/detection
    bGun                  = 0; % 1 to correct for spatially variant G
    bBatch          = 1;  % BATCH PROCESSING (not implemented yet) @@@ currently only overriding queries


    folder_name = uigetdir;
    cd(folder_name);
    file_names  = dir('*.sdt');
    [cal_name cal_path] = uigetfile('*cal*.mat');
    
    
    HDIM_PAR.file_path = folder_name;  
    HDIM_PAR.cal_name  = cal_name;   
    HDIM_PAR.cal_path  = cal_path;  
    
    
    fn=length(file_names);
    
    %%
    for fi=1:fn
        fi
        HDIM_PAR.file_name = file_names(fi).name;  
        HDIM_PAR.batch     = 1;
        
        [img HDIM_CAL HDIM_PAR HDIM_VIS, HDIM_CST] = if_hdim_load(HDIM_PAR);    

        HDIM_PAR.PC = 0;
        HDIM_PAR.Verbose = 2;   
        if ~isfield(HDIM_PAR.h,'ticVb') & HDIM_PAR.Verbose
            HDIM_PAR.h.ticVb = tic;
        end

        [HDIM_CAL HDIM_PAR] = if_hdim_getdimensions(img, HDIM_CAL, HDIM_PAR);
        HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR);
        img = if_hdim_cal_apply(img, HDIM_CAL, HDIM_PAR, 'options', [1 1 ~bBatch],'g-uneven',bGun,'msk',HDIM_VIS.msk_2d);
    
        HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR);
        HDIM_PAR.h.ticVb = if_voice('Dataset registered',HDIM_PAR.h.ticVb,HDIM_PAR.Verbose);
       
        save([file_names(fi).name(1:end-3)  'mat'],'img','HDIM_CAL','HDIM_PAR','HDIM_CST','HDIM_VIS');
    end
