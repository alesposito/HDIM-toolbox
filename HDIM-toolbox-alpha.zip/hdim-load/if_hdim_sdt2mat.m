
% load two SDT files, one per polarization channel, combine in a single image and save as mat file
% support multi file selection for batch conversion

function if_hdim_sdt2mat(varargin)

    if nargin==0
        [file_name1 file_path1] = uigetfile('*.sdt','Select first module (SDT file/M1)...','MultiSelect','On');    
        cd(file_path1);
    elseif nargin==1         
         file_name = varargin{1};
    else
        display([mfilename '> wrong number of arguments, trying to execute...'])         
    end
       
    if  ~iscell(file_name1)
        file_name1 = {file_name1};
    end
    
    fn = length(file_name1);
    
    h = waitbar(0,'File conversion in progress...')
    for fi=1:fn
        %% try detecting the second channel automatically
        is = findstr('_m1',file_name1{fi});
        if isempty(is), is=1; end    

        file_name2 = dir([file_name1{fi}(1:is) 'm2' file_name1{fi}(is+3:end)]);
        if length(file_name2)==1
            file_name2 = file_name2.name;
            file_path2 = file_path1;
            display([mfilename '> Second module located automatically (' file_name2 ')']);
        else
            [file_name2 file_path2] = uigetfile(['*.sdt','Select second module for ''' file_name1{fi} ''' (SDT file/M2)...']);    
        end

        % loading
        img = if_bh_loadsdt([file_path1 file_name1{fi}]);
        img = cat(3,img,if_bh_loadsdt([file_path1 file_name2]));

        % saving data        
        if fn>1            
            file_path = file_path1;
            file_name = [file_name1{fi}(1:end-4) '_hdim.mat'];
        else
            [file_name file_path] = uiputfile([file_name1(1:end-4) '_hdim.mat'],'Save as...');            
        end
        eval(['save ''' file_path file_name ''' img']);
        waitbar(fi/fn,h);
    end
    
    delete(h)
    
    