% HDIM_START  alpha
% This is the first public release of HDIM software which is provided to
% help interested colleague in familiarizing with this new data type. 
% This code works together with a larger software suite developped by
% Alessandro Esposito over the years (ImFluo), with many undocumented function.
% Therefore, we relese a simplified version. The prefix 'if' stays for
% ImFluo, and can be neglected. For future reference, HDIM-toolbox alpha
% has been spun-off from ImFluo4.1
%


%% INIT
% The minimum number of photons that has to me present in each spectral bin, 
% otherwise the pixel is masked if bMaskResults is set to 1. 
thr          = 10; 
bMaskResults = 1;

% Flat field correction on(1)/off(0);
bLightFieldCorrection = 1;

% Automaticly save results on hard-drive on(1)/off(1)
bSummarySave = 0;

%% LOADING
% Load one HDIM dataset
[img HDIM_CAL HDIM_PAR HDIM_VIS, HDIM_CST] = if_hdim_load;
    
%% Standardize data
% refresh HDIM_CAL and HDIM_PAR
[HDIM_CAL HDIM_PAR] = if_hdim_getdimensions(img, HDIM_CAL, HDIM_PAR);

% apply calibration
img = if_hdim_cal_apply(img, HDIM_CAL, HDIM_PAR, 'options', [1 1 1]);

% Generate mask (does not operate along time dimension and anisotorpy, but only space and colour)
HDIM_VIS = if_hdim_generatemask(img, thr, HDIM_VIS, HDIM_PAR);
%%
if_hdim_overview;
