% img should be x y lambda




function varargout = if_hdim_spec2rgb(img,varargin)

% set default parameters

    RGB_type = '';                                  % type of visualization
    wav0    = (450:(650-450+1)/size(img,3):650);    % default wavelength range
    bNorm   = 1;                                    % normalize output to 1
    bSmooth = 1;                                    % smooth outpur with median filter
    MEDFILT = [2 2];                                % Kernel of the median filter
    
    x_ = size(img,1);
    y_ = size(img,2);
    
    % parsing inputs
    if nargin>1
        for ai=1:2:nargin-1
            switch lower(varargin{ai})
                case 'type' % type of projection
                    RGB_type =  lower(varargin{ai+1});                                        
                case 'wavelength'
                    wav0 = varargin{ai+1};
                case 'imoptions' % [bNorm bSmooth medfilt]
                    tmp = varargin{ai+1};
                    bNorm = tmp(1);
                    bSmooth = tmp(2);
                    MEDFILT= [tmp(3) tmp(3)];
                    clear tmp
                case 'norm'
                    bNorm = varargin{ai+1};
                otherwise
                    display([mfilename '> optional argument ''' varargin{ai} ''' not recognized, skipping...'])
            end
        end
    end
    
    % valiudating inputs / assignig defaults
    if ~ismember(RGB_type,{'perception','true'})        
        RGB_type = 'perception';        
        display([mfilename '> argument value for ''type'' not recognized or not provided, setting to default value(' RGB_type ')'])
    end


    % wavelength bins    
	wav = [0 420 445 470 495 520 545 570 595 620 1000];

   % RGB equivalent for wavelength bins    
   switch RGB_type
       case 'perception'
            r_ch = [ 0.0  0.0  7.9
                     0.0  2.0 10.0
                     0.0  4.2  7.0
                     0.0  5.0  2.0
                     0.0  4.0  0.0
                     1.2  3.0  0.0
                     1.8  3.0  0.0
                     3.0  2.4  0.0
                     4.0  1.6  0.0
                     5.0  0.0  0.0];
       case 'true'
            r_ch = [ 0 0 1
                     0 0 1
                     0 0 1
                     0 0 1
                     0 1 0
                     0 1 0
                     0 1 0
                     1 0 0
                     1 0 0
                     1 0 0];           
       end   
   

    
    % pre-binning onto the 10 fundamental bins
    tmp = zeros([x_ y_ 10]);
    for i=1:10
       idx = find(wav0>wav(i) & wav0<wav(i+1));
       tmp(:,:,i) = sum(img(:,:,idx),3);
    end            
    
    clear img
    
    % generation of rgb
    rgb = zeros([x_ y_ 3]);
    for ic=1:3
        rgb(:,:,ic)= sumch(tmp.*shiftdim(repmat(r_ch(:,ic),[1 x_ y_]),1),3);
    end
    
    clear tmp
     
    if bSmooth
        rgb = cat(3,medfilt2(rgb(:,:,1),[2 2]),medfilt2(rgb(:,:,2),[2 2]),medfilt2(rgb(:,:,3),[2 2]));
    end
    
    if bNorm==1
        %rgbnorm = shiftdim(repmat(squeeze(max(max(rgb))),[1 x_ y_]),1);
        rgbnorm = shiftdim(repmat(squeeze(max(rgb(:))),[3 x_ y_]),1);
        %rgbnorm = shiftdim(repmat(squeeze(mean(rgb(:))+4*std(rgb(:))),[3 x_ y_]),1);
        rgbnorm(rgbnorm==0)=1;
        rgb = rgb./rgbnorm;
    end
    
    if nargout==0
        figure
        imshow(imadjust(rgb,[0 .9],[0 1]));        
        title(['RGB image (' RGB_type ')'])
    else
        varargout{1} = rgb;
    end
    
    