% Create structures useful for HDIM analysis.
% VERSION 4

function [HDIM_CAL, HDIM_PAR, HDIM_VIS, HDIM_CST] = if_hdim_init
    
    % Constant Definitions
    HDIM_CST.CHDEF_PAR = 1; % Parallel component
    HDIM_CST.CHDEF_PER = 2; % Perpendicular component
    
    % HDIM_CAL definition
    HDIM_CAL = struct('Info',...   % general information values
                             struct('r_target',[],...                                    % rarget r-value for calibrations
                                    'sp_line',[],...                                     % spectral comb for calirbations 
                                    'notes','',...                                       % annotations
                                    'date',date),...                                     % creation date
                      'Sp1',[],...                                                       % polynomial regression values for spectral calibration of spectral channel 1
                      'Sp2',[],...                                                       % polynomial regression values for spectral calibration of spectral channel 1                      
                      'A',[],...                                                         % anisotropy calibration, A parameter (Jovin's nomenclature)
                      'B',[],...                                                         % anisotropy calibration, B parameter (Jovin's nomenclature)                      
                      'G',[],...                                                         % G-factor calibration 
                      'IL',[],...                                                        % compensation of illimination or pixel dwell time unevenness
                      'Time',[],...
                      'a_wav1',[],...                                                    % wavelength axis, channel 1
                      'a_wav2',[],...                                                    % wavelength axis, channel 2
                      'a_time',[])                                                       % time axis)                                                      % Shift (in time bin number units of the second TCSPC card relative to the first
                    
                      
    % HDIM_PAR definition
    HDIM_PAR = struct('ChPar',HDIM_CST.CHDEF_PAR,...                                     % Parallel Channel
                      'ChPer',HDIM_CST.CHDEF_PER,...                                     % Perpendicular Channel
                      'SpElements', (1:16),...                                           % Spectral Elements
                      'Sp1Band',[],...                                                   % spectral band - channel 1
                      'Sp2Band',[],...                                                   % spectral band - channel 2
                      'Sp1Res',[],...                                                    % spectral resolution - channel 1
                      'Sp2Res',[],...                                                    % spectral resolution - channel 2                      
                      'T_Res',[],...                                                     % time resolution
                      'T_Per',[],...                                                     % time period
                      'T_Ome',[],...                                                     % time - harmonic
                      'T_t',[],...                                                       % time bins                      
                      'x_dim',[],...                                                     % X dimension
                      'y_dim',[],...                                                     % Y dimension                      
                      's_dim',[],...                                                     % spectral dimension                      
                      't_dim',[],...                                                     % number of time bins
                      's_ele',[],...                                                     % number of spectral elements to be analyzed
                      't_ele',[],...                                                     % number of time bins to be analyzed   
                      'idx_par',[],...                                                   % matrix indexes for spectral channels of parallel detector
                      'idx_per',[],...                                                   % matrix indexes for spectral channels of perpendicolar detector                     
                      'Verbose',2,...                                                    % verbose feedback 0: off, 1: display, 2: speach enabled
                      'PC',0,...
                      'filter_display',struct);                                                           % parallel computing                   
                  
     HDIM_PAR.filter_display.status = 0;
     
     HDIM_PAR.h = struct('ticVb',[]);                                                    % verbose function, tic Id             
                  
                  
                  
%% --- DEFINITION OF LOOKUP TABLES

    % Intensity specific lookup table (Jet with white background)
    HDIM_VIS.I_LUT = jet(64);
    HDIM_VIS.I_LUT(1,:) = [1 1 1];
    
    % Masks
    HDIM_VIS.msk_2d = 1;
    HDIM_VIS.msk_hd = 1;

    % Anisotropy specific lookup table
    HDIM_VIS.R_LUT = [  1.0000    1.0000    1.0000
                             0         0    1.0000
                             0    0.0769    0.9231         
                             0    0.1538    0.8462
                             0    0.2308    0.7692
                             0    0.3077    0.6923
                             0    0.3846    0.6154
                             0    0.4615    0.5385
                             0    0.5385    0.4615
                             0    0.6154    0.3846
                             0    0.6923    0.3077
                             0    0.7692    0.2308
                             0    0.8462    0.1538
                             0    0.9231    0.0769
                             0    1.0000         0
                        0.0833    1.0000         0
                        0.1667    1.0000         0
                        0.2500    1.0000         0
                        0.3333    1.0000         0
                        0.4167    1.0000         0
                        0.5000    1.0000         0
                        0.5833    1.0000         0
                        0.6667    1.0000         0
                        0.7500    1.0000         0
                        0.8333    1.0000         0
                        0.9167    1.0000         0
                        1.0000    1.0000         0
                        1.0000    0.9091         0
                        1.0000    0.8182         0
                        1.0000    0.7273         0
                        1.0000    0.6364         0
                        1.0000    0.5455         0
                        1.0000    0.4545         0
                        1.0000    0.3636         0
                        1.0000    0.2727         0
                        1.0000    0.1818         0
                        1.0000    0.0909         0
                        1.0000         0         0
                        0.9631         0         0
                        0.9263         0         0
                        0.8894         0         0
                        0.8526         0         0
                        0.8157         0         0
                        0.7788         0         0
                        0.7420         0         0
                        0.7051         0         0
                        0.6683         0         0
                        0.6314         0         0
                        0.5946         0         0
                        0.5577         0         0
                        0.5208         0         0
                        0.4840         0         0
                        0.4471         0         0
                        0.4103         0         0
                        0.3734         0         0
                        0.3365         0         0
                        0.2997         0         0
                        0.2628         0         0
                        0.2260         0         0
                        0.1891         0         0
                        0.1522         0         0
                        0.1154         0         0
                        0.0785         0         0
                        0.0417         0         0];

    % 2D scatter plot specific lookup table
    HDIM_VIS.D_LUT = [  1.0000    1.0000    1.0000
                        0.8353    0.8353    0.8353
                        0.6667    0.6667    0.6667
                        0.5020    0.5020    0.5020
                        0.3333    0.3333    0.3333
                        0.1686    0.1686    0.1686
                             0         0         0
                             0         0    1.0000
                             0    0.1216    1.0000
                             0    0.2431    1.0000
                             0    0.3686    1.0000
                             0    0.4902    1.0000
                             0    0.6118    1.0000
                             0    0.7333    1.0000
                             0    0.8588    1.0000
                             0    0.9804    1.0000
                             0    1.0000    0.8980
                             0    1.0000    0.8392
                             0    1.0000    0.7765
                             0    1.0000    0.7176
                             0    1.0000    0.6588
                             0    1.0000    0.6000
                             0    1.0000    0.5373
                             0    1.0000    0.4784
                             0    1.0000    0.4196
                             0    1.0000    0.3608
                             0    1.0000    0.2980
                             0    1.0000    0.2392
                             0    1.0000    0.1804
                             0    1.0000    0.1216
                             0    1.0000    0.0588
                             0    1.0000         0
                        0.0431    1.0000         0
                        0.0902    1.0000         0
                        0.1333    1.0000         0
                        0.1765    1.0000         0
                        0.2235    1.0000         0
                        0.2667    1.0000         0
                        0.3098    1.0000         0
                        0.3569    1.0000         0
                        0.4000    1.0000         0
                        0.4431    1.0000         0
                        0.4902    1.0000         0
                        0.5333    1.0000         0
                        0.5804    1.0000         0
                        0.6235    1.0000         0
                        0.6667    1.0000         0
                        0.7137    1.0000         0
                        0.7569    1.0000         0
                        0.8000    1.0000         0
                        0.8471    1.0000         0
                        0.8902    1.0000         0
                        0.9333    1.0000         0
                        0.9804    1.0000         0
                        1.0000    0.9765         0
                        1.0000    0.9490         0
                        1.0000    0.9216         0
                        1.0000    0.8941         0
                        1.0000    0.8667         0
                        1.0000    0.8392         0
                        1.0000    0.8157         0
                        1.0000    0.7882         0
                        1.0000    0.7608         0
                        1.0000    0.7333         0
                        1.0000    0.7059         0
                        1.0000    0.6784         0
                        1.0000    0.6510         0
                        1.0000    0.6235         0
                        1.0000    0.5961         0
                        1.0000    0.5686         0
                        1.0000    0.5412         0
                        1.0000    0.5137         0
                        1.0000    0.4902         0
                        1.0000    0.4627         0
                        1.0000    0.4353         0
                        1.0000    0.4078         0
                        1.0000    0.3804         0
                        1.0000    0.3529         0
                        1.0000    0.3255         0
                        1.0000    0.2980         0
                        1.0000    0.2706         0
                        1.0000    0.2431         0
                        1.0000    0.2157         0
                        1.0000    0.1882         0
                        1.0000    0.1647         0
                        1.0000    0.1373         0
                        1.0000    0.1098         0
                        1.0000    0.0824         0
                        1.0000    0.0549         0
                        1.0000    0.0275         0
                        1.0000         0         0
                        0.9882         0         0
                        0.9725         0         0
                        0.9608         0         0
                        0.9451         0         0
                        0.9333         0         0
                        0.9176         0         0
                        0.9059         0         0
                        0.8941         0         0
                        0.8784         0         0
                        0.8667         0         0
                        0.8510         0         0
                        0.8392         0         0
                        0.8235         0         0
                        0.8118         0         0
                        0.8000         0         0
                        0.7843         0         0
                        0.7725         0         0
                        0.7569         0         0
                        0.7451         0         0
                        0.7294         0         0
                        0.7176         0         0
                        0.7020         0         0
                        0.6902         0         0
                        0.6784         0         0
                        0.6627         0         0
                        0.6510         0         0
                        0.6353         0         0
                        0.6235         0         0
                        0.6078         0         0
                        0.5961         0         0
                        0.5843         0         0
                        0.5686         0         0
                        0.5569         0         0
                        0.5412         0         0
                        0.5294         0         0
                        0.5137         0         0
                        0.5020         0         0];

% Lifetime specific colormap
HDIM_VIS.T_LUT = [  0.8314    0.8157    0.7843
                    0.0323    0.0323    0.5766
                    0.0645    0.0645    0.5907
                    0.0968    0.0968    0.6048
                    0.1290    0.1290    0.6190
                    0.1613    0.1613    0.6331
                    0.1935    0.1935    0.6472
                    0.2258    0.2258    0.6613
                    0.2581    0.2581    0.6754
                    0.2903    0.2903    0.6895
                    0.3226    0.3226    0.7036
                    0.3548    0.3548    0.7177
                    0.3871    0.3871    0.7319
                    0.4194    0.4194    0.7460
                    0.4516    0.4516    0.7601
                    0.4839    0.4839    0.7742
                    0.5161    0.5161    0.7883
                    0.5484    0.5484    0.8024
                    0.5806    0.5806    0.8165
                    0.6129    0.6129    0.8306
                    0.6452    0.6452    0.8448
                    0.6774    0.6774    0.8589
                    0.7097    0.7097    0.8730
                    0.7419    0.7419    0.8871
                    0.7742    0.7742    0.9012
                    0.8065    0.8065    0.9153
                    0.8387    0.8387    0.9294
                    0.8710    0.8710    0.9435
                    0.9032    0.9032    0.9577
                    0.9355    0.9355    0.9718
                    0.9677    0.9677    0.9859
                    1.0000    1.0000    1.0000
                    0.9844    0.9688    0.9688
                    0.9688    0.9375    0.9375
                    0.9531    0.9063    0.9063
                    0.9375    0.8750    0.8750
                    0.9219    0.8438    0.8438
                    0.9063    0.8125    0.8125
                    0.8906    0.7813    0.7813
                    0.8750    0.7500    0.7500
                    0.8594    0.7188    0.7188
                    0.8438    0.6875    0.6875
                    0.8281    0.6563    0.6563
                    0.8125    0.6250    0.6250
                    0.7969    0.5938    0.5938
                    0.7813    0.5625    0.5625
                    0.7656    0.5313    0.5313
                    0.7500    0.5000    0.5000
                    0.7344    0.4688    0.4688
                    0.7188    0.4375    0.4375
                    0.7031    0.4063    0.4063
                    0.6875    0.3750    0.3750
                    0.6719    0.3438    0.3438
                    0.6563    0.3125    0.3125
                    0.6406    0.2813    0.2813
                    0.6250    0.2500    0.2500
                    0.6094    0.2188    0.2188
                    0.5938    0.1875    0.1875
                    0.5781    0.1563    0.1563
                    0.5625    0.1250    0.1250
                    0.5469    0.0938    0.0938
                    0.5313    0.0625    0.0625
                    0.5156    0.0313    0.0313
                    0.5000         0         0];