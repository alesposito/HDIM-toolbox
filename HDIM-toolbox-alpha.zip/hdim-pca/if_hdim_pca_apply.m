% VERSION 4.1




prj= [];
data_length  = size(img,1);
brick_length = n2;
brick_number = ceil(data_length/brick_length); % total number of bricks to be processes. The last one may be shorter then the others

%COEFF = medfilt2(COEFF,[3 3]);

hw = waitbar(0,'Applying projections...');

for brick_current = 1:brick_number
    waitbar(brick_current/brick_number,hw)
    
    idx1 = (brick_current-1)*brick_length+1;           
    idx2 = brick_current*brick_length;
    
    switch ExtractionType
        case 5
            if brick_current*brick_length<=data_length        
                aa0 = img(idx1:idx2,:) - repmat(mean(img(idx1:idx2,:),1),brick_length,1); 
                prj(idx1:idx2,:) = aa0*HDIM_CAL.pca.coeff;
            else
                data_remain = data_length-(brick_current-1)*brick_length;
                aa0 = img(idx1:end,:) - repmat(mean(img(idx1:end,:),1),data_remain,1); 
                prj((brick_current-1)*brick_length+1:data_length,:) = aa0*HDIM_CAL.pca.coeff;        
            end
        case {1,2,3}
            if brick_current*brick_length<=data_length                        
                %prj(idx1:idx2,:) = -img(idx1:idx2,:)*HDIM_CAL.pca.coeff; v4.0
                prj(idx1:idx2,:) = img(idx1:idx2,:)*HDIM_CAL.pca.coeff;
            else                
                %prj(idx1:data_length,:) = -img(idx1:end,:)*HDIM_CAL.pca.coeff; v4.0
                prj(idx1:data_length,:) = img(idx1:end,:)*HDIM_CAL.pca.coeff;                        
            end
    end
end


%% compute min-max projection values
idx1    = find(reshape(HDIM_VIS.msk_2d,[prod(size(HDIM_VIS.msk_2d)) 1])==1);
pca_lim = zeros([4 2]);
for ii=1:4
    if ii<4
        tmp = abs(medfilt2(prj(:,ii),[4 4],'symmetric'));
    else
        tmp = abs(medfilt2(sumch(prj(:,4:end),3),'symmetric'));
    end
    pca_lim(ii,1) = min(tmp(idx1));
    pca_lim(ii,2) = median(tmp(idx1))+3*std(tmp(idx1));
end

if bIOprojections~=1 % unless these values are loaded store them in HDIM_CAL
    HDIM_CAL.pca.limits = pca_lim;
end

%%
clear aa0 brick_length data_length brick_number brick_current idx1 idx2 ii
%%
close(hw)

