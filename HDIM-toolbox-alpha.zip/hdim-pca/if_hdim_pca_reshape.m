% VERSION 5.2
%
% img = if_hdim_pca_reshape(img, HDIM_PAR, 'option1','value1',...)
% img = if_hdim_pca_reshape(img, HDIM_PAR)
%
% OPTIONS
%
% 'Reduce', [0] / 1 data reduction
% 'Reduction Method', not implemented yet @@@
% 'Save Original', [0] / 1, save original dataset, useful to recover pre data reduction image
% 'Normalize', [0] / 1, normalization
% 'Normalization Method', not implemented yet @@@
% 'Direction', ['Forward' or 'F'] and 'Backward' or 'B' reshape to perform or after having performed PCA
%
% v5.1: normalize brigthness to total count
% v5.2: new normalization to median

function varargout = if_hdim_pca_reshape(img, HDIM_PAR, varargin)
    
    % Set default values
    bReduce = 0;
    bSave   = 0;
    bNorm   = 0;
    bDir    = 0; % 0: forward 1: backword
    
    % Parse input
    if nargin>2
        for i=1:2:length(varargin)
            switch lower(varargin{i})
                case 'reduce'
                    if varargin{i+1}==1
                        bReduce = 1;
                    elseif varargin{i+1}==0
                        bReduce = 0;
                    else
                        beep
                        error([mfilename '> value for option ' varargin{i} ' not supported']);
                    end
                    
                case 'normalize'
                    if varargin{i+1}==1
                        bNorm = 1;
                    elseif varargin{i+1}==0
                        bNorm = 0;
                    else
                        beep
                        error([mfilename '> value for option ' varargin{i} ' not supported']);
                    end

                case 'save original'
                    if varargin{i+1}==1
                        bSave = 1;
                    elseif varargin{i+1}==0
                        bSave = 0;
                    else
                        beep
                        error([mfilename '> value for option ' varargin{i} ' not supported']);
                    end
                    
                case 'direction'
                    if strcmp(lower(varargin{i+1}),'f') | strcmp(lower(varargin{i+1}),'forward')
                        bDir = 0;
                    elseif strcmp(lower(varargin{i+1}),'b') | strcmp(lower(varargin{i+1}),'backward')
                        bDir = 1;
                    else
                        beep
                        error([mfilename '> value for option ' varargin{i} ' not supported']);
                    end
                    
                    
                otherwise
                    beep
                    error([mfilename '> option ' varargin{i} ' not supported']);
            end
        end        
    end
    
    if bSave & ~bDir % save original file during forward transformation
        display([mfilename '> saving image'])
        if isfield(HDIM_PAR,'file_path')
            if ~isempty(HDIM_PAR.file_path)
                save_path =  [upper(HDIM_PAR.file_name(1:end-4)) '_DATA'];
                if ~isdir(save_path)
                    mkdir(save_path)
                end
            end
        else
            save_path = './';
        end
        eval(['save ''' save_path 'HDIM_TMPFILE_PCARED.MAT'' img'])
    end   
    
    if ~bDir % FORWARD RESHAPING        
        
        % - v5.2
        dc = sumch(img,[3 4]);
        if bNorm
            img = img * ((2^20)/median(nonzeros(dc)));
        end
        % -
        
        if bReduce % DATA REDUCTION
            tmp = [];
            % n_sp spectral channels (max 16)
            % for each of them provide total count
            %     A & B value negleting anisotropy
            %     R0 and Rinf

            % total count            
            % --- v5.0 and v5.2---
            tmp(:,:,HDIM_PAR.s_ele,1) = sumch(reshape(img(:,:,[HDIM_PAR.s_ele HDIM_PAR.s_ele+HDIM_PAR.s_dim],HDIM_PAR.t_ele),[HDIM_PAR.x_dim HDIM_PAR.y_dim HDIM_PAR.s_dim 2*HDIM_PAR.t_dim]),4);
            % --- v5.1 ---           
            %tmp(:,:,HDIM_PAR.s_ele,1) = sumch(reshape(img(:,:,[HDIM_PAR.s_ele HDIM_PAR.s_ele+HDIM_PAR.s_dim],HDIM_PAR.t_ele),[HDIM_PAR.x_dim HDIM_PAR.y_dim HDIM_PAR.s_dim 2*HDIM_PAR.t_dim]),4);
            %tmp(:,:,HDIM_PAR.s_ele,1) = 1000000*tmp(:,:,HDIM_PAR.s_ele,1)/sumch(tmp(:,:,:,1),[1 2 3]);

            % up to v5.1
            %dc = reshape(squeeze(sum(tmp,3)),[HDIM_PAR.x_dim*HDIM_PAR.y_dim 1]);
            %if bNorm
            %    tmp(:,:,HDIM_PAR.s_ele,1) = 1000000*tmp(:,:,HDIM_PAR.s_ele,1)./repmat(squeeze(sum(tmp(:,:,HDIM_PAR.s_ele,1),3)),[1 1 HDIM_PAR.s_dim]);
            %end

            
            
            
            
            % R0 and Rinf
            tmp(:,:,HDIM_PAR.s_ele,2) =  squeeze(img(:,:,HDIM_PAR.idx_par(HDIM_PAR.s_ele),HDIM_PAR.t_ele(1))        -       img(:,:,HDIM_PAR.idx_per(HDIM_PAR.s_ele),HDIM_PAR.t_ele(1)))        ./ (      img(:,:,HDIM_PAR.idx_par(HDIM_PAR.s_ele),HDIM_PAR.t_ele(1))        + 2*      img(:,:,HDIM_PAR.idx_per(HDIM_PAR.s_ele),HDIM_PAR.t_ele(1)));
            tmp(:,:,HDIM_PAR.s_ele,3) =   (sumch(img(:,:,HDIM_PAR.idx_par(HDIM_PAR.s_ele),HDIM_PAR.t_ele(2:end)),4) - sumch(img(:,:,HDIM_PAR.idx_per(HDIM_PAR.s_ele),HDIM_PAR.t_ele(2:end)),4)) ./ (sumch(img(:,:,HDIM_PAR.idx_par(HDIM_PAR.s_ele),HDIM_PAR.t_ele(2:end)),4) + 2*sumch(img(:,:,HDIM_PAR.idx_per(HDIM_PAR.s_ele),HDIM_PAR.t_ele(2:end)),4));           

            % A/B    
            %warning off
            for i=1:HDIM_PAR.s_dim
                [G, S] = if_lifetime_phasors(squeeze(img(:,:,HDIM_PAR.s_ele(i)+(HDIM_PAR.ChPar-1)*HDIM_PAR.s_dim,HDIM_PAR.t_ele)+2*img(:,:,HDIM_PAR.s_ele(i)+(HDIM_PAR.ChPer-1)*HDIM_PAR.s_dim,HDIM_PAR.t_ele)), HDIM_PAR.T_Res,1,0,0);
                tmp(:,:,i,4) = G;
                tmp(:,:,i,5) = S;
            end

            clear img G S
            img = reshape(squeeze((tmp(:,:,HDIM_PAR.s_ele,:))),[HDIM_PAR.x_dim*HDIM_PAR.y_dim HDIM_PAR.s_dim*5]);        
            clear tmp
            img(isnan(img))=0;
            n_tm = 5;
        else % RESHAPING WITHOUT DATA REDUCTION

            img = reshape(squeeze((img(:,:,HDIM_PAR.s_ele,HDIM_PAR.t_ele))),[HDIM_PAR.x_dim*HDIM_PAR.y_dim HDIM_PAR.s_dim*HDIM_PAR.t_dim]);   
            % up to v5.1
            %dc = sumch(img,2);
            %if bNorm
            %    img = 1000*img./repmat(squeeze(sum(img,2)),[1 size(img,2)]);        
            %    %img = 400*img./repmat(dc,[1 size(img,2)]);
            %end
        end
        img(isnan(img))=0;
        
        dc = reshape(dc,[HDIM_PAR.x_dim*HDIM_PAR.y_dim 1]);
        
    else % BACKWARD RESHAPING
       if bSave
           load 'HDIM_TMPFILE_PCARED.M'
       else
           if bReduce
               img = reshape(img,[HDIM_PAR.x_dim HDIM_PAR.y_dim prod(size(img))/(HDIM_PAR.x_dim*HDIM_PAR.y_dim)]); 
           else
               img = reshape(img,[HDIM_PAR.x_dim HDIM_PAR.y_dim 2*HDIM_PAR.s_dim size(img)/(HDIM_PAR.x_dim*HDIM_PAR.y_dim*2*HDIM_PAR.s_dim)]); 
           end
       end
    end
    
    
    
if nargout==1
    varargout{1} = img;
elseif nargout==2
    varargout{1} = img;
    varargout{2} = dc;
end
    