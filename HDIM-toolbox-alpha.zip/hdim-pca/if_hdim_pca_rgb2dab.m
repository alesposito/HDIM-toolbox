    mk = HDIM_VIS.msk_2d;
  
    
    if HDIM_PAR.filter_display.status
        R = if_hdim_filterdisplay(prj(:,:,3),HDIM_PAR);
        G = if_hdim_filterdisplay(prj(:,:,2),HDIM_PAR);
        B = if_hdim_filterdisplay(prj(:,:,1),HDIM_PAR);
        O = if_hdim_filterdisplay(sumch(prj(:,:,n_comp+1:end),[3]),HDIM_PAR);
    end
    
          
        try 
            % estimate the median value within the 5 percintile brighetest pixels
            pca_limits = HDIM_CAL.pca.limits;
            RV = (sort(nonzeros(abs(R.*mk)))-pca_limits(3,1))/(pca_limits(3,2)-pca_limits(3,1));
            RV = median(RV(round(size(RV,1)*.95):end));
            GV = (sort(nonzeros(abs(G.*mk)))-pca_limits(2,1))/(pca_limits(2,2)-pca_limits(2,1));
            GV = median(GV(round(size(GV,1)*.95):end));
            BV = (sort(nonzeros(abs(B.*mk)))-pca_limits(1,1))/(pca_limits(1,2)-pca_limits(1,1));
            BV = median(BV(round(size(BV,1)*.95):end));
            OV = (sort(nonzeros(abs(O.*mk)))-pca_limits(4,1))/(pca_limits(4,2)-pca_limits(4,1));
            OV = median(OV(round(size(OV,1)*.95):end));
            sat1 = max([RV GV BV]);
            %sat2 = max([RV GV BV OV]);
        catch
            sat1 = 1;
            %sat2 = 1;
        end
        
        
    
    R3 = HDIM_VIS.msk_2d.*((R-HDIM_CAL.pca.limits(3,1))/(sat1*(HDIM_CAL.pca.limits(3,2)-HDIM_CAL.pca.limits(3,1))));
    G3 = HDIM_VIS.msk_2d.*((G-HDIM_CAL.pca.limits(2,1))/(sat1*(HDIM_CAL.pca.limits(2,2)-HDIM_CAL.pca.limits(2,1))));                    
    B3 = HDIM_VIS.msk_2d.*((B-HDIM_CAL.pca.limits(1,1))/(sat1*(HDIM_CAL.pca.limits(1,2)-HDIM_CAL.pca.limits(1,1))));
    %O3 = HDIM_VIS.msk_2d.*((abs(sumch(prj(:,:,4:end),3))-HDIM_CAL.pca.limits(4,1))/(sat1*(HDIM_CAL.pca.limits(4,2)-HDIM_CAL.pca.limits(4,1))));
        
    R4 = HDIM_VIS.msk_2d.*((R-HDIM_CAL.pca.limits(3,1))/(sat1*(HDIM_CAL.pca.limits(3,2)-HDIM_CAL.pca.limits(3,1))));
    G4 = HDIM_VIS.msk_2d.*((G-HDIM_CAL.pca.limits(2,1))/(sat1*(HDIM_CAL.pca.limits(2,2)-HDIM_CAL.pca.limits(2,1))));                    
    B4 = HDIM_VIS.msk_2d.*((B-HDIM_CAL.pca.limits(1,1))/(sat1*(HDIM_CAL.pca.limits(1,2)-HDIM_CAL.pca.limits(1,1))));
    O4 = HDIM_VIS.msk_2d.*((O-HDIM_CAL.pca.limits(4,1))/(sat1*(HDIM_CAL.pca.limits(4,2)-HDIM_CAL.pca.limits(4,1))));
       
    
    R3(R3<0)=0;
    G3(G3<0)=0;
    B3(B3<0)=0;
    R3(R3>1)=1;
    G3(G3>1)=1;
    B3(B3>1)=1;

    R4(R4<0)=0;
    G4(G4<0)=0;
    B4(B4<0)=0;
    O4(O4<0)=0;

    R4(R4>1)=1;
    G4(G4>1)=1;
    B4(B4>1)=1;
    O4(O4>1)=1;
    
    %DAB_K = (R);
    %DAB_M = (B);
    %DAB_C = (G);
    %DAB_Y = (O);

    
% get code to identify the RGB assignment and enhance contrast!



% switch ExtractionType
%     case 1,2        
%         DAB_K = 1.5*(R);
%         DAB_M = 1.5*(B);
%         DAB_C = 1.5*(G);
%     case 3
%             
%         R = R./max(R(:));
%         G = G./max(G(:));
%         B = B./max(B(:));
%         
%         DAB_K = R;
%         DAB_M = B;
%         DAB_C = G; 
%             
% end

%if n_comp>3
    %DAB_Y = 1.5*if_hdim_pca_stretch(sum(prj(:,:,4:end),3), mk, 'std');
%else
%    DAB_Y = zeros(size(DAB_K));    
%end

DAB_CMYK3 = cat(3,G3,B3,zeros(size(R3)),R3);
DAB_CMYK4 = cat(3,G4,B4,O4,R4);

inprof = iccread('CMYK.icc');
outprof = iccread('RGB.icc');
C = makecform('icc',inprof,outprof);

DAB_RGB3 = real(applycform(DAB_CMYK3,C));
DAB_RGB4 = real(applycform(DAB_CMYK4,C));

DAB_R3 = if_hdim_filterdisplay(DAB_RGB3(:,:,1),HDIM_PAR);
DAB_G3 = if_hdim_filterdisplay(DAB_RGB3(:,:,2),HDIM_PAR);
DAB_B3 = if_hdim_filterdisplay(DAB_RGB3(:,:,3),HDIM_PAR);

DAB_R4 = if_hdim_filterdisplay(DAB_RGB4(:,:,1),HDIM_PAR);
DAB_G4 = if_hdim_filterdisplay(DAB_RGB4(:,:,2),HDIM_PAR);
DAB_B4 = if_hdim_filterdisplay(DAB_RGB4(:,:,3),HDIM_PAR);

DAB_R3(HDIM_VIS.msk_2d==0)=1;
DAB_G3(HDIM_VIS.msk_2d==0)=1;
DAB_B3(HDIM_VIS.msk_2d==0)=1;

DAB_R4(HDIM_VIS.msk_2d==0)=1;
DAB_G4(HDIM_VIS.msk_2d==0)=1;
DAB_B4(HDIM_VIS.msk_2d==0)=1;

DAB_RGB3 = cat(3,DAB_R3,DAB_G3,DAB_B3);
DAB_RGB4 = cat(3,DAB_R4,DAB_G4,DAB_B4);

HDIM_PAR.h.figs.digitalstaining3 = figure('name',['Digital Staining 3 (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
imshow(DAB_RGB3)
title('PCA->DAB3')

HDIM_PAR.h.figs.digitalstaining4 = figure('name',['Digital Staining 4 (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
imshow(DAB_RGB4)
title('PCA->DAB4')