
function HDIM_PAR = if_hdim_pca_show(data,n_comp,HDIM_PAR,HDIM_CAL,HDIM_VIS);

    c = [1 2 3 4]; % channel assignment
    
 
    
    pca_limits = zeros([4 2]);
    pca_limits(1:4,1) = HDIM_CAL.pca.limits(c,1);
    pca_limits(1:4,2) = HDIM_CAL.pca.limits(c,2);
    
    clim = zeros([4 2]);  
    
    
    %pca_limits=[45 850; 0 340; 0 45]
    
    mk = HDIM_VIS.msk_2d;
  
    
    if HDIM_PAR.filter_display.status
        R = if_hdim_filterdisplay(data(:,:,c(1)),HDIM_PAR);
        G = if_hdim_filterdisplay(data(:,:,c(2)),HDIM_PAR);
        B = if_hdim_filterdisplay(data(:,:,c(3)),HDIM_PAR);
        O = if_hdim_filterdisplay(sumch(data(:,:,n_comp+1:end),[3]),HDIM_PAR);
    end
    
    
    %%
    clim(1,:) = mean(nonzeros(R.*mk))+3*[-1 +1]*std(nonzeros(R.*mk)) ;
    clim(2,:) = mean(nonzeros(G.*mk))+3*[-1 +1]*std(nonzeros(G.*mk)) ;
    clim(3,:) = mean(nonzeros(B.*mk))+3*[-1 +1]*std(nonzeros(B.*mk)) ;
    clim(4,:) = mean(nonzeros(O.*mk))+3*[-1 +1]*std(nonzeros(O.*mk)) ;
    %%
    
    
    %R(~mk) = -Inf;
    %G(~mk) = -Inf;
    %B(~mk) = -Inf;
    %O(~mk) = -Inf;        
    
%     R(~mk) = min(R(:))-eps;
%     G(~mk) = min(G(:))-eps;
%     B(~mk) = min(B(:))-eps;
%     O(~mk) = min(O(:))-eps;
    RGB  = cat(3,R, G, B);
    
    %RGBd = RGB;
%      stretch_method = 'min-3s'
%       RGBd = cat(3,mk.*if_hdim_pca_stretch(abs(R), mk, stretch_method),...
%                    mk.*if_hdim_pca_stretch(abs(G), mk, stretch_method),...
%                    mk.*if_hdim_pca_stretch(abs(B), mk, stretch_method));
%     
%     
      
        try 
            % estimate the median value within the 5 percintile brighetest pixels
            RV = (sort(nonzeros(abs(R.*mk)))-pca_limits(1,1))/(pca_limits(1,2)-pca_limits(1,1));
            RV = median(RV(round(size(RV,1)*.95):end));
            GV = (sort(nonzeros(abs(G.*mk)))-pca_limits(2,1))/(pca_limits(2,2)-pca_limits(2,1));
            GV = median(GV(round(size(GV,1)*.95):end));
            BV = (sort(nonzeros(abs(B.*mk)))-pca_limits(3,1))/(pca_limits(3,2)-pca_limits(3,1));
            BV = median(BV(round(size(BV,1)*.95):end));
            %OV = (sort(nonzeros(abs(O.*mk)))-pca_limits(4,1))/(pca_limits(4,2)-pca_limits(4,1));
            %OV = median(OV(round(size(OV,1)*.95):end));
            sat = max([RV GV BV]);
        catch
            sat = 1;
        end
        
        RGBd  = cat(3,  mk.*((abs(R)-pca_limits(1,1))/(sat*(pca_limits(1,2)-pca_limits(1,1)))),...
                        mk.*((abs(G)-pca_limits(2,1))/(sat*(pca_limits(2,2)-pca_limits(2,1)))),...
                        mk.*((abs(B)-pca_limits(3,1))/(sat*(pca_limits(3,2)-pca_limits(3,1)))));

                     
                                          
     RGBd(RGBd<0)=0;
     RGBd(RGBd>1)=1;
                 
    HDIM_PAR.h.figs.pca = figure('name',['PCA (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
    imshow(RGBd)
    title('PCA')

    %%
    HDIM_PAR.h.figs.pca_components = figure('name',['PCA components (' HDIM_PAR.file_name(1:end-4) ')'],'numbertitle','off');
    for i=1:n_comp+1
        subplot(round(sqrt(n_comp+1)),ceil(sqrt(n_comp+1)),i);        
        
        if i<=n_comp
            imagesc(RGB(:,:,i));
            title([num2str(i) ' comp.'])            
        else
            imagesc(O);
            title('all others')
        end
                
        %caxis(clim(i,:))
        
        axis image
        axis off
        
        %colormap(HDIM_VIS.I_LUT)
        colormap(jet)
        colorbar
    end
